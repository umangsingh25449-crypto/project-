"""Application configuration. Secrets always come from environment variables."""
import os
from datetime import timedelta
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def _origins(value: str):
    return [o.strip() for o in value.split(",") if o.strip()]


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY")
    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY")
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=float(os.environ.get("JWT_ACCESS_TOKEN_HOURS", 8)))
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL", "sqlite:///loan_app.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    CORS_ORIGINS = _origins(os.environ.get("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"))
    MODEL_PATH = str((BASE_DIR / os.environ.get("MODEL_PATH", "ml/artifacts/model.joblib")).resolve())
    RATELIMIT_STORAGE_URI = os.environ.get("RATELIMIT_STORAGE_URI", "memory://")
    RATELIMIT_ENABLED = True
    JSON_SORT_KEYS = False
    TESTING = False


class TestConfig(Config):
    TESTING = True
    SECRET_KEY = "test-secret-key-test-secret-key-test-secret-key"
    JWT_SECRET_KEY = "test-jwt-secret-test-jwt-secret-test-jwt-secret"
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"  # separate from the real database
    RATELIMIT_ENABLED = False
