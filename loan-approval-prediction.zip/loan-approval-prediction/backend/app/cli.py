"""Command line helpers.

    flask --app run init-db
    flask --app run create-admin --email you@example.com --name "Your Name"
"""
import click

from .extensions import db
from .models import User
from .schemas.validators import EMAIL_RE, password_errors


def register_cli(app):
    @app.cli.command("init-db")
    def init_db():
        """Create all database tables (safe to run repeatedly)."""
        db.create_all()
        click.echo("Database tables are ready.")

    @app.cli.command("create-admin")
    @click.option("--email", prompt=True)
    @click.option("--name", prompt="Full name")
    @click.password_option("--password", prompt=True, confirmation_prompt=True, help="Typed securely at the prompt.")
    def create_admin(email, name, password):
        """Create (or promote) an administrator. The password is never stored in files or shell history."""
        email = email.strip().lower()
        if not EMAIL_RE.match(email):
            raise click.ClickException("Invalid email address.")
        problem = password_errors(password)
        if problem:
            raise click.ClickException(problem)
        db.create_all()
        user = User.query.filter_by(email=email).first()
        if user:
            user.role, user.is_active = "admin", True
            click.echo(f"Existing user {email} promoted to admin.")
        else:
            user = User(full_name=name.strip(), email=email, role="admin")
            user.set_password(password)
            db.session.add(user)
            click.echo(f"Admin {email} created.")
        db.session.commit()
