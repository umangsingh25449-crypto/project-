"""Server-side input validation. Each validator returns (clean_data, errors_dict)."""
import re

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")

CHOICES = {
    "employment_status": {"self_employed", "not_self_employed"},
    "dependents": {"0", "1", "2", "3+"},
    "education": {"graduate", "not_graduate"},
    "property_area": {"urban", "semiurban", "rural"},
}


def password_errors(password):
    if not isinstance(password, str) or len(password) < 8:
        return "Password must be at least 8 characters long."
    if len(password) > 128:
        return "Password must be at most 128 characters long."
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return "Password must contain at least one letter and one number."
    return None


def clean_name(value, errors, key="full_name"):
    if not isinstance(value, str) or not (2 <= len(value.strip()) <= 100):
        errors[key] = "Full name must be between 2 and 100 characters."
        return None
    return " ".join(value.split())


def validate_registration(data):
    errors = {}
    name = clean_name(data.get("full_name"), errors)
    email = data.get("email")
    if not isinstance(email, str) or not EMAIL_RE.match(email.strip()) or len(email) > 255:
        errors["email"] = "Enter a valid email address."
        email = None
    else:
        email = email.strip().lower()
    pw_err = password_errors(data.get("password"))
    if pw_err:
        errors["password"] = pw_err
    elif data.get("password") != data.get("confirm_password"):
        errors["confirm_password"] = "Passwords do not match."
    return {"full_name": name, "email": email, "password": data.get("password")}, errors


def validate_password_change(data):
    errors = {}
    if not isinstance(data.get("current_password"), str) or not data.get("current_password"):
        errors["current_password"] = "Current password is required."
    pw_err = password_errors(data.get("new_password"))
    if pw_err:
        errors["new_password"] = pw_err
    elif data.get("new_password") != data.get("confirm_password"):
        errors["confirm_password"] = "Passwords do not match."
    return errors


def _number(data, key, errors, label, minimum, maximum, integer=False, min_exclusive=False):
    value = data.get(key)
    if value is None or value == "" or isinstance(value, bool):
        errors[key] = f"{label} is required."
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        errors[key] = f"{label} must be a number."
        return None
    if number != number or number in (float("inf"), float("-inf")):
        errors[key] = f"{label} must be a valid number."
        return None
    if integer:
        if number != int(number):
            errors[key] = f"{label} must be a whole number."
            return None
        number = int(number)
    too_low = number <= minimum if min_exclusive else number < minimum
    if too_low:
        errors[key] = f"{label} must be greater than {minimum:g}." if min_exclusive else f"{label} cannot be less than {minimum:g}."
        return None
    if number > maximum:
        errors[key] = f"{label} cannot be more than {maximum:,.0f}."
        return None
    return number


def validate_prediction_input(data):
    errors = {}
    clean = {
        "applicant_income": _number(data, "applicant_income", errors, "Applicant income", 0, 10_000_000, min_exclusive=True),
        "coapplicant_income": _number(data, "coapplicant_income", errors, "Co-applicant income", 0, 10_000_000),
        "loan_amount": _number(data, "loan_amount", errors, "Loan amount", 0, 10_000, min_exclusive=True),
        "loan_term": _number(data, "loan_term", errors, "Loan term", 12, 480, integer=True),
        "credit_history": _number(data, "credit_history", errors, "Credit history", 0, 1, integer=True),
    }
    for key, allowed in CHOICES.items():
        value = data.get(key)
        if value not in allowed:
            errors[key] = f"Select a valid option for {key.replace('_', ' ')}."
        clean[key] = value
    return clean, errors
