"""Flask application factory."""
import logging
import os

from flask import Flask
from werkzeug.exceptions import HTTPException

from .config import Config
from .extensions import cors, db, jwt, limiter
from .utils.responses import fail


def create_app(config_object=Config):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_object)
    os.makedirs(app.instance_path, exist_ok=True)

    if not app.config["TESTING"] and (not app.config["SECRET_KEY"] or not app.config["JWT_SECRET_KEY"]):
        raise RuntimeError(
            "SECRET_KEY and JWT_SECRET_KEY must be set. Copy backend/.env.example to backend/.env and fill them in."
        )

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    db.init_app(app)
    jwt.init_app(app)
    limiter.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}})

    register_jwt_handlers()
    register_error_handlers(app)

    from .routes import admin, auth, dashboard, predictions, profile

    for module in (auth, predictions, dashboard, profile, admin):
        app.register_blueprint(module.bp)

    @app.get("/api/health")
    def health():
        return {"success": True, "data": {"status": "ok"}, "message": None}

    from .cli import register_cli

    register_cli(app)
    return app


def register_jwt_handlers():
    @jwt.unauthorized_loader
    def missing(_reason):
        return fail("UNAUTHORIZED", "Authentication required.", 401)

    @jwt.invalid_token_loader
    def invalid(_reason):
        return fail("INVALID_TOKEN", "Your session is invalid. Please log in again.", 401)

    @jwt.expired_token_loader
    def expired(_header, _payload):
        return fail("TOKEN_EXPIRED", "Your session has expired. Please log in again.", 401)


def register_error_handlers(app):
    @app.errorhandler(HTTPException)
    def http_error(exc):
        code = {404: "NOT_FOUND", 405: "METHOD_NOT_ALLOWED", 429: "RATE_LIMITED"}.get(exc.code, "HTTP_ERROR")
        message = "Too many requests. Please slow down and try again shortly." if exc.code == 429 else exc.description
        return fail(code, message, exc.code)

    @app.errorhandler(Exception)
    def unexpected(exc):
        db.session.rollback()
        app.logger.exception("Unhandled error")  # stack trace goes to the log only, never to the client
        return fail("SERVER_ERROR", "Something went wrong on our side. Please try again.", 500)
