from datetime import datetime, timedelta

from flask import Blueprint, g, request
from sqlalchemy import func

from ..extensions import db
from ..models import LoanApplication, User
from ..utils.auth import auth_required
from ..utils.responses import fail, ok, page_meta
from .predictions import apply_filters, apply_sort, page_args

bp = Blueprint("admin", __name__, url_prefix="/api/admin")


@bp.get("/stats")
@auth_required(admin=True)
def stats():
    total_apps = LoanApplication.query.count()
    approved = LoanApplication.query.filter_by(prediction_result="approved").count()
    week_ago = datetime.utcnow() - timedelta(days=7)
    recent = LoanApplication.query.order_by(LoanApplication.created_at.desc(), LoanApplication.id.desc()).limit(8).all()
    return ok(
        {
            "total_users": User.query.count(),
            "active_users": User.query.filter_by(is_active=True).count(),
            "admins": User.query.filter_by(role="admin").count(),
            "total_predictions": total_apps,
            "approved": approved,
            "rejected": total_apps - approved,
            "approval_rate": round(approved / total_apps * 100, 1) if total_apps else 0,
            "predictions_last_7_days": LoanApplication.query.filter(LoanApplication.created_at >= week_ago).count(),
            "recent_activity": [a.to_dict(include_user=True) for a in recent],
        }
    )


@bp.get("/users")
@auth_required(admin=True)
def list_users():
    counts = (
        db.session.query(LoanApplication.user_id, func.count(LoanApplication.id).label("n"))
        .group_by(LoanApplication.user_id)
        .subquery()
    )
    query = db.session.query(User, func.coalesce(counts.c.n, 0)).outerjoin(counts, counts.c.user_id == User.id)
    search = (request.args.get("search") or "").strip()
    if search:
        like = f"%{search}%"
        query = query.filter(db.or_(User.email.ilike(like), User.full_name.ilike(like)))
    query = query.order_by(User.created_at.desc(), User.id.desc())
    page, per_page = page_args(request.args)
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    items = [{**u.to_dict(), "prediction_count": n} for u, n in pagination.items]
    return ok({"items": items, "pagination": page_meta(pagination)})


@bp.patch("/users/<int:user_id>")
@auth_required(admin=True)
def update_user(user_id):
    user = db.session.get(User, user_id)
    if user is None:
        return fail("NOT_FOUND", "User not found.", 404)
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return fail("BAD_REQUEST", "Request body must be JSON.", 400)
    if user.id == g.current_user.id:
        return fail("FORBIDDEN", "You cannot change your own role or status.", 403)
    if "role" in data:
        if data["role"] not in ("user", "admin"):
            return fail("VALIDATION_ERROR", "Role must be 'user' or 'admin'.", 422)
        user.role = data["role"]
    if "is_active" in data:
        if not isinstance(data["is_active"], bool):
            return fail("VALIDATION_ERROR", "is_active must be true or false.", 422)
        user.is_active = data["is_active"]
    db.session.commit()
    return ok({"user": user.to_dict()}, "User updated.")


@bp.get("/applications")
@auth_required(admin=True)
def list_applications():
    query = LoanApplication.query.join(User, LoanApplication.user_id == User.id)
    query = apply_filters(query, request.args)
    user_id = request.args.get("user_id", type=int)
    if user_id:
        query = query.filter(LoanApplication.user_id == user_id)
    query = apply_sort(query, request.args)
    page, per_page = page_args(request.args)
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    return ok({"items": [a.to_dict(include_user=True) for a in pagination.items], "pagination": page_meta(pagination)})


@bp.delete("/applications/<int:app_id>")
@auth_required(admin=True)
def delete_application(app_id):
    record = db.session.get(LoanApplication, app_id)
    if record is None:
        return fail("NOT_FOUND", "Application not found.", 404)
    db.session.delete(record)
    db.session.commit()
    return ok(message="Application record deleted.")
