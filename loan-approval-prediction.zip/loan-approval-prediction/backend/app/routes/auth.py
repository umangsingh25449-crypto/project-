from flask import Blueprint, current_app, g, request
from flask_jwt_extended import create_access_token

from ..extensions import db, limiter
from ..models import User
from ..schemas.validators import validate_password_change, validate_registration
from ..utils.auth import auth_required
from ..utils.responses import fail, ok

bp = Blueprint("auth", __name__, url_prefix="/api/auth")

# A real hash used to keep response time similar when the email does not exist.
_DUMMY_HASH = User(password_hash="x")
_DUMMY_HASH.set_password("not-a-real-password-1")


@bp.post("/register")
@limiter.limit("10 per hour")
def register():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return fail("BAD_REQUEST", "Request body must be JSON.", 400)
    clean, errors = validate_registration(data)
    if errors:
        return fail("VALIDATION_ERROR", "Please correct the highlighted fields.", 422, errors)
    if User.query.filter_by(email=clean["email"]).first():
        return fail("EMAIL_EXISTS", "An account with this email already exists.", 409, {"email": "This email is already registered."})
    user = User(full_name=clean["full_name"], email=clean["email"], role="user")
    user.set_password(clean["password"])
    db.session.add(user)
    db.session.commit()
    current_app.logger.info("New user registered id=%s", user.id)
    return ok({"user": user.to_dict()}, "Account created. You can now log in.", 201)


@bp.post("/login")
@limiter.limit("10 per minute")
def login():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return fail("BAD_REQUEST", "Request body must be JSON.", 400)
    email, password = data.get("email"), data.get("password")
    if not isinstance(email, str) or not isinstance(password, str) or not email or not password:
        return fail("VALIDATION_ERROR", "Email and password are required.", 422)
    user = User.query.filter_by(email=email.strip().lower()).first()
    valid = (user or _DUMMY_HASH).check_password(password) and user is not None and user.is_active
    if not valid:
        current_app.logger.warning("Failed login attempt")  # never log the email/password
        return fail("INVALID_CREDENTIALS", "Invalid email or password.", 401)
    token = create_access_token(identity=str(user.id))
    return ok({"access_token": token, "user": user.to_dict()}, "Logged in successfully.")


@bp.get("/me")
@auth_required()
def me():
    return ok({"user": g.current_user.to_dict()})


@bp.post("/change-password")
@limiter.limit("10 per hour")
@auth_required()
def change_password():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return fail("BAD_REQUEST", "Request body must be JSON.", 400)
    errors = validate_password_change(data)
    user = g.current_user
    if not errors and not user.check_password(data["current_password"]):
        errors["current_password"] = "Current password is incorrect."
    if not errors and data["current_password"] == data["new_password"]:
        errors["new_password"] = "New password must be different from the current one."
    if errors:
        return fail("VALIDATION_ERROR", "Please correct the highlighted fields.", 422, errors)
    user.set_password(data["new_password"])
    db.session.commit()
    return ok(message="Password updated successfully.")
