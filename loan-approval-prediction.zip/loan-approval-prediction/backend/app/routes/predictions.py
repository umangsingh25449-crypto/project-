from datetime import datetime, timedelta

from flask import Blueprint, current_app, g, request

from ..extensions import db, limiter
from ..models import LoanApplication
from ..schemas.validators import validate_prediction_input
from ..services.prediction_service import ModelNotAvailableError, get_model
from ..utils.auth import auth_required
from ..utils.responses import fail, ok, page_meta

bp = Blueprint("predictions", __name__, url_prefix="/api/predictions")

SORTABLE = {
    "created_at": LoanApplication.created_at,
    "loan_amount": LoanApplication.loan_amount,
    "id": LoanApplication.id,
    "prediction_result": LoanApplication.prediction_result,
}


def model_unavailable(exc):
    current_app.logger.error("Model unavailable: %s", exc)
    return fail("MODEL_NOT_AVAILABLE", str(exc), 503)


def apply_filters(query, args):
    """Shared by user history and admin listing: search / result filter / date range."""
    result = args.get("result")
    if result in ("approved", "rejected"):
        query = query.filter(LoanApplication.prediction_result == result)
    search = (args.get("search") or "").strip()
    if search:
        if search.lstrip("#").isdigit():
            query = query.filter(LoanApplication.id == int(search.lstrip("#")))
        else:
            like = f"%{search}%"
            query = query.filter(
                db.or_(LoanApplication.model_version.ilike(like), LoanApplication.property_area.ilike(like))
            )
    for key, op in (("date_from", "ge"), ("date_to", "lt")):
        raw = args.get(key)
        if raw:
            try:
                day = datetime.strptime(raw, "%Y-%m-%d")
            except ValueError:
                continue
            if op == "ge":
                query = query.filter(LoanApplication.created_at >= day)
            else:
                query = query.filter(LoanApplication.created_at < day + timedelta(days=1))
    return query


def apply_sort(query, args):
    column = SORTABLE.get(args.get("sort_by"), LoanApplication.created_at)
    return query.order_by(column.asc() if args.get("order") == "asc" else column.desc(), LoanApplication.id.desc())


def page_args(args, default=10, maximum=100):
    page = max(args.get("page", 1, type=int) or 1, 1)
    per_page = min(max(args.get("per_page", default, type=int) or default, 1), maximum)
    return page, per_page


@bp.get("/model-info")
@auth_required()
def model_info():
    try:
        return ok(get_model().info())
    except ModelNotAvailableError as exc:
        return model_unavailable(exc)


@bp.post("")
@limiter.limit("30 per minute")
@auth_required()
def create_prediction():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return fail("BAD_REQUEST", "Request body must be JSON.", 400)
    clean, errors = validate_prediction_input(data)  # any client-supplied "result" fields are ignored
    if errors:
        return fail("VALIDATION_ERROR", "Please correct the highlighted fields.", 422, errors)
    model = get_model()
    try:
        outcome = model.predict(clean)
        info = model.info()
    except ModelNotAvailableError as exc:
        return model_unavailable(exc)

    record = LoanApplication(
        user_id=g.current_user.id,
        prediction_result=outcome["result"],
        prediction_score=outcome["score"],
        model_version=outcome["model_version"],
        **clean,
    )
    db.session.add(record)
    db.session.commit()
    return ok(
        {"application": record.to_dict(), "feature_importance": info["feature_importance"][:5]},
        "Prediction completed.",
        201,
    )


@bp.get("")
@auth_required()
def list_predictions():
    query = LoanApplication.query.filter_by(user_id=g.current_user.id)  # ownership enforced here
    query = apply_sort(apply_filters(query, request.args), request.args)
    page, per_page = page_args(request.args)
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    return ok({"items": [a.to_dict() for a in pagination.items], "pagination": page_meta(pagination)})


def _own_record(app_id):
    # Return 404 (not 403) for other people's records so IDs cannot be probed.
    return LoanApplication.query.filter_by(id=app_id, user_id=g.current_user.id).first()


@bp.get("/<int:app_id>")
@auth_required()
def get_prediction(app_id):
    record = _own_record(app_id)
    if record is None:
        return fail("NOT_FOUND", "Application not found.", 404)
    importance = []
    try:
        importance = get_model().info()["feature_importance"][:5]
    except ModelNotAvailableError:
        pass
    return ok({"application": record.to_dict(), "feature_importance": importance})


@bp.delete("/<int:app_id>")
@auth_required()
def delete_prediction(app_id):
    record = _own_record(app_id)
    if record is None:
        return fail("NOT_FOUND", "Application not found.", 404)
    db.session.delete(record)
    db.session.commit()
    return ok(message="Application record deleted.")
