from flask import Blueprint, g, request

from ..extensions import db
from ..schemas.validators import clean_name
from ..utils.auth import auth_required
from ..utils.responses import fail, ok

bp = Blueprint("profile", __name__, url_prefix="/api/profile")


@bp.get("")
@auth_required()
def get_profile():
    user = g.current_user
    return ok({"user": user.to_dict(), "total_predictions": user.applications.count()})


@bp.put("")
@auth_required()
def update_profile():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return fail("BAD_REQUEST", "Request body must be JSON.", 400)
    errors = {}
    name = clean_name(data.get("full_name"), errors)
    if errors:
        return fail("VALIDATION_ERROR", "Please correct the highlighted fields.", 422, errors)
    g.current_user.full_name = name  # email and role can NOT be changed here
    db.session.commit()
    return ok({"user": g.current_user.to_dict()}, "Profile updated.")
