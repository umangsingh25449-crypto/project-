from datetime import datetime

from flask import Blueprint, g

from ..extensions import db
from ..models import LoanApplication
from ..utils.auth import auth_required
from ..utils.responses import ok

bp = Blueprint("dashboard", __name__, url_prefix="/api/dashboard")


def month_buckets(count=6):
    now = datetime.utcnow()
    year, month = now.year, now.month
    months = []
    for _ in range(count):
        months.append((year, month))
        month -= 1
        if month == 0:
            year, month = year - 1, 12
    return list(reversed(months))


@bp.get("/stats")
@auth_required()
def stats():
    base = LoanApplication.query.filter_by(user_id=g.current_user.id)
    total = base.count()
    approved = base.filter_by(prediction_result="approved").count()
    rejected = total - approved
    return ok(
        {
            "total_predictions": total,
            "approved": approved,
            "rejected": rejected,
            "approval_rate": round(approved / total * 100, 1) if total else 0,
            "distribution": [
                {"name": "Approved", "value": approved},
                {"name": "Rejected", "value": rejected},
            ],
        }
    )


@bp.get("/activity")
@auth_required()
def activity():
    buckets = month_buckets(6)
    start = datetime(buckets[0][0], buckets[0][1], 1)
    rows = (
        db.session.query(LoanApplication.created_at, LoanApplication.prediction_result)
        .filter(LoanApplication.user_id == g.current_user.id, LoanApplication.created_at >= start)
        .all()
    )
    counts = {b: {"approved": 0, "rejected": 0} for b in buckets}
    for created_at, result in rows:
        key = (created_at.year, created_at.month)
        if key in counts:
            counts[key][result] += 1
    monthly = [
        {
            "month": f"{y}-{m:02d}",
            "label": datetime(y, m, 1).strftime("%b %Y"),
            "approved": counts[(y, m)]["approved"],
            "rejected": counts[(y, m)]["rejected"],
            "total": counts[(y, m)]["approved"] + counts[(y, m)]["rejected"],
        }
        for (y, m) in buckets
    ]
    recent = (
        LoanApplication.query.filter_by(user_id=g.current_user.id)
        .order_by(LoanApplication.created_at.desc(), LoanApplication.id.desc())
        .limit(5)
        .all()
    )
    return ok({"monthly": monthly, "recent": [a.to_dict() for a in recent]})
