"""Consistent JSON envelope for every endpoint.

Success: {"success": true,  "message": "...", "data": {...}}
Failure: {"success": false, "error": {"code": "...", "message": "...", "details": {...}}}
"""
from flask import jsonify


def ok(data=None, message=None, status=200):
    return jsonify({"success": True, "message": message, "data": data}), status


def fail(code, message, status=400, details=None):
    body = {"success": False, "error": {"code": code, "message": message}}
    if details:
        body["error"]["details"] = details
    return jsonify(body), status


def page_meta(pagination):
    return {
        "page": pagination.page,
        "per_page": pagination.per_page,
        "total": pagination.total,
        "pages": pagination.pages,
    }
