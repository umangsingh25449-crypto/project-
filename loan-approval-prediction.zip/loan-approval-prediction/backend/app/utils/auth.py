from functools import wraps

from flask import g
from flask_jwt_extended import get_jwt_identity, verify_jwt_in_request

from ..extensions import db
from ..models import User
from .responses import fail


def auth_required(admin: bool = False):
    """Require a valid JWT (and optionally the admin role). Sets g.current_user."""

    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            verify_jwt_in_request()
            try:
                user = db.session.get(User, int(get_jwt_identity()))
            except (TypeError, ValueError):
                user = None
            if user is None or not user.is_active:
                return fail("UNAUTHORIZED", "Authentication required.", 401)
            if admin and user.role != "admin":
                return fail("FORBIDDEN", "Administrator access required.", 403)
            g.current_user = user
            return fn(*args, **kwargs)

        return wrapper

    return decorator
