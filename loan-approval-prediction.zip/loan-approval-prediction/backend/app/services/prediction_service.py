from flask import current_app

from ml.predict import LoanModel, ModelNotAvailableError  # noqa: F401  (re-exported)


def get_model() -> LoanModel:
    """One LoanModel per app; it reloads automatically if the model file is re-trained."""
    model = current_app.extensions.get("loan_model")
    if model is None or str(model.model_path) != str(current_app.config["MODEL_PATH"]):
        model = LoanModel(current_app.config["MODEL_PATH"])
        current_app.extensions["loan_model"] = model
    return model
