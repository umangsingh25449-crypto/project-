"""Database models (SQLAlchemy). Portable to PostgreSQL: only standard column types are used."""
from datetime import datetime, timezone

from sqlalchemy import CheckConstraint, Index
from werkzeug.security import check_password_hash, generate_password_hash

from ..extensions import db


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)  # stored as naive UTC


class User(db.Model):
    __tablename__ = "users"
    __table_args__ = (CheckConstraint("role IN ('user','admin')", name="ck_users_role"),)

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(255), nullable=False, unique=True, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(10), nullable=False, default="user")
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=utcnow, onupdate=utcnow)

    applications = db.relationship(
        "LoanApplication", back_populates="user", cascade="all, delete-orphan", lazy="dynamic"
    )

    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)  # salted PBKDF2/scrypt hash

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            "id": self.id,
            "full_name": self.full_name,
            "email": self.email,
            "role": self.role,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() + "Z",
        }


class LoanApplication(db.Model):
    __tablename__ = "loan_applications"
    __table_args__ = (
        CheckConstraint("applicant_income > 0", name="ck_app_income"),
        CheckConstraint("coapplicant_income >= 0", name="ck_app_coincome"),
        CheckConstraint("loan_amount > 0", name="ck_app_loan_amount"),
        CheckConstraint("loan_term > 0", name="ck_app_loan_term"),
        CheckConstraint("credit_history IN (0,1)", name="ck_app_credit"),
        CheckConstraint("prediction_result IN ('approved','rejected')", name="ck_app_result"),
        Index("ix_app_user_created", "user_id", "created_at"),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    applicant_income = db.Column(db.Float, nullable=False)  # monthly
    coapplicant_income = db.Column(db.Float, nullable=False, default=0)  # monthly
    loan_amount = db.Column(db.Float, nullable=False)  # in thousands (same unit as the dataset)
    loan_term = db.Column(db.Integer, nullable=False)  # months
    credit_history = db.Column(db.Integer, nullable=False)  # 1 = meets guidelines, 0 = does not
    employment_status = db.Column(db.String(20), nullable=False)  # self_employed | not_self_employed
    dependents = db.Column(db.String(2), nullable=False)  # 0,1,2,3+
    education = db.Column(db.String(20), nullable=False)  # graduate | not_graduate
    property_area = db.Column(db.String(20), nullable=False)  # urban | semiurban | rural
    prediction_result = db.Column(db.String(10), nullable=False)
    prediction_score = db.Column(db.Float, nullable=True)
    model_version = db.Column(db.String(60), nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)

    user = db.relationship("User", back_populates="applications")

    def to_dict(self, include_user=False):
        data = {
            "id": self.id,
            "applicant_income": self.applicant_income,
            "coapplicant_income": self.coapplicant_income,
            "loan_amount": self.loan_amount,
            "loan_term": self.loan_term,
            "credit_history": self.credit_history,
            "employment_status": self.employment_status,
            "dependents": self.dependents,
            "education": self.education,
            "property_area": self.property_area,
            "prediction_result": self.prediction_result,
            "prediction_score": self.prediction_score,
            "model_version": self.model_version,
            "created_at": self.created_at.isoformat() + "Z",
        }
        if include_user:
            data["user"] = {"id": self.user.id, "full_name": self.user.full_name, "email": self.user.email}
        return data
