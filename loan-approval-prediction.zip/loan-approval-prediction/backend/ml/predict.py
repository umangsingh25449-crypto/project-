"""Inference wrapper used by the Flask backend. Never returns hardcoded or random results."""
import json
from pathlib import Path

import joblib

from ml.features import api_to_model_row


class ModelNotAvailableError(Exception):
    """Raised when the trained model artifact is missing or unreadable."""


class LoanModel:
    def __init__(self, model_path):
        self.model_path = Path(model_path)
        self.metadata_path = self.model_path.with_name("model_metadata.json")
        self._pipeline = None
        self._metadata = None
        self._mtime = None

    def _load(self):
        if not self.model_path.exists() or not self.metadata_path.exists():
            raise ModelNotAvailableError(
                "The trained model was not found. Train it first with: python -m ml.train_model"
            )
        mtime = self.model_path.stat().st_mtime
        if self._pipeline is not None and mtime == self._mtime:
            return
        try:
            self._pipeline = joblib.load(self.model_path)
            self._metadata = json.loads(self.metadata_path.read_text())
            self._mtime = mtime
        except Exception as exc:  # corrupt file, incompatible scikit-learn version...
            self._pipeline = None
            raise ModelNotAvailableError(f"The model file could not be loaded ({type(exc).__name__}). Re-train the model.") from exc

    def info(self):
        self._load()
        m = self._metadata
        return {
            "model_version": m["model_version"],
            "algorithm": m["algorithm"],
            "trained_at": m["trained_at"],
            "threshold": m["threshold"],
            "features_used": m["features_used"],
            "features_excluded": m["features_excluded"],
            "test_metrics": m["selected_test_metrics"],
            "feature_importance": m["feature_importance"],
            "disclaimer": m["disclaimer"],
        }

    def predict(self, clean_input: dict) -> dict:
        self._load()
        score = float(self._pipeline.predict_proba(api_to_model_row(clean_input))[0][1])
        approved = score >= self._metadata["threshold"]
        return {
            "result": "approved" if approved else "rejected",
            "score": round(score, 4),
            "model_version": self._metadata["model_version"],
        }
