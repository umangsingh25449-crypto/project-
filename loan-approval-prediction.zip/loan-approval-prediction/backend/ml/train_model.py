"""Train and compare classifiers, then save the best full pipeline.

Run from the backend/ folder:
    python -m ml.train_model
    python -m ml.train_model --data ../dataset/loan_train.csv
"""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split

from ml.features import CATEGORICAL_COLUMNS, EXCLUDED_COLUMNS, FEATURE_COLUMNS, FEATURE_LABELS, TARGET
from ml.pipeline import build_pipeline

ML_DIR = Path(__file__).resolve().parent
DEFAULT_DATA = ML_DIR.parent.parent / "dataset" / "loan_train.csv"
DEFAULT_OUTPUT = ML_DIR / "artifacts"
RANDOM_STATE = 42
TEST_SIZE = 0.2
THRESHOLD = 0.5


def load_dataset(path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}.\n"
            "Download the Kaggle 'Loan Prediction Problem Dataset' (train file) and save it as "
            "dataset/loan_train.csv. See dataset/README.md for step-by-step instructions."
        )
    df = pd.read_csv(path)
    missing = [c for c in FEATURE_COLUMNS + [TARGET] if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")
    return df


def prepare(df):
    """Return X (features only) and y (1 = approved). Protected/ID columns never enter X."""
    df = df.dropna(subset=[TARGET]).drop_duplicates()
    y = (df[TARGET].astype(str).str.strip().str.upper() == "Y").astype(int)
    X = df[FEATURE_COLUMNS].copy()
    for col in CATEGORICAL_COLUMNS:
        X[col] = X[col].astype(object).where(X[col].notna(), np.nan)
        X[col] = X[col].map(lambda v: v if isinstance(v, float) else str(v).strip())
    return X.reset_index(drop=True), y.reset_index(drop=True)


def split(X, y, random_state=RANDOM_STATE, test_size=TEST_SIZE):
    # Stratified so train/test keep the same approved/rejected ratio. Split happens BEFORE any
    # fitting, so imputers/scalers/encoders only ever learn from training rows (no leakage).
    return train_test_split(X, y, test_size=test_size, stratify=y, random_state=random_state)


def metrics_for(pipeline, X, y):
    proba = pipeline.predict_proba(X)[:, 1]
    pred = (proba >= THRESHOLD).astype(int)
    return {
        "accuracy": float(accuracy_score(y, pred)),
        "precision": float(precision_score(y, pred, zero_division=0)),
        "recall": float(recall_score(y, pred, zero_division=0)),
        "f1": float(f1_score(y, pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y, proba)),
        "confusion_matrix": confusion_matrix(y, pred, labels=[0, 1]).tolist(),  # [[TN, FP],[FN, TP]]
    }


def candidates():
    return {
        "logistic_regression": (
            LogisticRegression(max_iter=2000, class_weight="balanced"),
            {"model__C": [0.1, 1.0, 10.0]},
        ),
        "random_forest": (
            RandomForestClassifier(n_estimators=300, class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1),
            {"model__max_depth": [3, 5, 8], "model__min_samples_leaf": [3, 5, 10]},
        ),
    }


def train(df, output_dir=DEFAULT_OUTPUT, data_path=None, verbose=True):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    X, y = prepare(df)
    X_train, X_test, y_train, y_test = split(X, y)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)

    results, fitted = {}, {}
    for name, (estimator, grid) in candidates().items():
        # class_weight="balanced" handles class imbalance; selection uses CV ROC-AUC on TRAIN data only
        search = GridSearchCV(build_pipeline(estimator), grid, scoring="roc_auc", cv=cv, n_jobs=1)
        search.fit(X_train, y_train)
        fitted[name] = search.best_estimator_
        results[name] = {
            "best_params": {k.replace("model__", ""): v for k, v in search.best_params_.items()},
            "cv_roc_auc": float(search.best_score_),
            "test": metrics_for(search.best_estimator_, X_test, y_test),
        }
        if verbose:
            print(f"[{name}] CV ROC-AUC={search.best_score_:.3f}  test={ {k: round(v, 3) for k, v in results[name]['test'].items() if k != 'confusion_matrix'} }")

    # Selection criterion: best cross-validated ROC-AUC (not accuracy, not the test set)
    best_name = max(results, key=lambda n: results[n]["cv_roc_auc"])
    best = fitted[best_name]

    # Global importance of each ORIGINAL input column (permutation importance on held-out data)
    perm = permutation_importance(best, X_test, y_test, scoring="roc_auc", n_repeats=10, random_state=RANDOM_STATE)
    raw = np.clip(perm.importances_mean, 0, None)
    total = raw.sum() or 1.0
    importance = sorted(
        ({"feature": c, "label": FEATURE_LABELS[c], "importance": float(v / total)} for c, v in zip(FEATURE_COLUMNS, raw)),
        key=lambda d: d["importance"],
        reverse=True,
    )

    now = datetime.now(timezone.utc)
    version = f"{best_name}-{now.strftime('%Y%m%d-%H%M%S')}"
    metadata = {
        "model_version": version,
        "algorithm": best_name,
        "trained_at": now.isoformat(),
        "sklearn_version": sklearn.__version__,
        "threshold": THRESHOLD,
        "random_state": RANDOM_STATE,
        "test_size": TEST_SIZE,
        "n_rows": int(len(X)),
        "n_train": int(len(X_train)),
        "n_test": int(len(X_test)),
        "approval_rate_in_data": float(y.mean()),
        "features_used": FEATURE_COLUMNS,
        "features_excluded": EXCLUDED_COLUMNS,
        "selection_criterion": "highest 5-fold cross-validated ROC-AUC on the training split",
        "comparison": results,
        "selected_test_metrics": results[best_name]["test"],
        "feature_importance": importance,
        "data_sha256": hashlib.sha256(Path(data_path).read_bytes()).hexdigest() if data_path else None,
        "disclaimer": "Educational prototype. Scores are not calibrated probabilities and not a lending decision.",
    }
    joblib.dump(best, output_dir / "model.joblib")
    (output_dir / "model_metadata.json").write_text(json.dumps(metadata, indent=2))
    if verbose:
        print(f"\nSelected: {best_name}  ->  saved {output_dir / 'model.joblib'}  (version {version})")
    return metadata


def main():
    parser = argparse.ArgumentParser(description="Train the loan approval model.")
    parser.add_argument("--data", default=str(DEFAULT_DATA), help="path to the CSV dataset")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT))
    args = parser.parse_args()
    try:
        df = load_dataset(args.data)
    except (FileNotFoundError, ValueError) as exc:
        raise SystemExit(f"\nERROR: {exc}")
    train(df, args.output_dir, data_path=args.data)


if __name__ == "__main__":
    main()
