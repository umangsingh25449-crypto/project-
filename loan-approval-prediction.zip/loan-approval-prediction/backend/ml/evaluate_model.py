"""Re-evaluate the saved model on the same held-out test split used during training.

    python -m ml.evaluate_model
    python -m ml.evaluate_model --data ../dataset/loan_train.csv
"""
import argparse
import json
from pathlib import Path

import joblib
from sklearn.metrics import classification_report

from ml.train_model import DEFAULT_DATA, DEFAULT_OUTPUT, load_dataset, metrics_for, prepare, split


def evaluate(df, artifact_dir=DEFAULT_OUTPUT):
    artifact_dir = Path(artifact_dir)
    model_file, meta_file = artifact_dir / "model.joblib", artifact_dir / "model_metadata.json"
    if not model_file.exists() or not meta_file.exists():
        raise FileNotFoundError("No trained model found. Run:  python -m ml.train_model")
    pipeline = joblib.load(model_file)
    meta = json.loads(meta_file.read_text())
    X, y = prepare(df)
    _, X_test, _, y_test = split(X, y, meta["random_state"], meta["test_size"])
    result = metrics_for(pipeline, X_test, y_test)
    result["model_version"] = meta["model_version"]
    result["report"] = classification_report(
        y_test, pipeline.predict_proba(X_test)[:, 1] >= meta["threshold"], target_names=["rejected", "approved"], zero_division=0
    )
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default=str(DEFAULT_DATA))
    parser.add_argument("--artifact-dir", default=str(DEFAULT_OUTPUT))
    args = parser.parse_args()
    try:
        result = evaluate(load_dataset(args.data), args.artifact_dir)
    except (FileNotFoundError, ValueError) as exc:
        raise SystemExit(f"\nERROR: {exc}")
    print(f"Model version: {result['model_version']}")
    for key in ("accuracy", "precision", "recall", "f1", "roc_auc"):
        print(f"{key:>10}: {result[key]:.3f}")
    print("\nConfusion matrix  [[TN, FP], [FN, TP]]:")
    print(result["confusion_matrix"])
    print("\n" + result["report"])
    out = Path(args.artifact_dir) / "evaluation.json"
    out.write_text(json.dumps({k: v for k, v in result.items() if k != "report"}, indent=2))
    print(f"Saved {out}")


if __name__ == "__main__":
    main()
