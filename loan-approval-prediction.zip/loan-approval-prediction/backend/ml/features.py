"""Feature policy shared by training AND inference (one source of truth).

Dataset: Kaggle "Loan Prediction Problem Dataset" (columns documented in dataset/README.md).

Feature policy
--------------
* Loan_ID    -> identifier, dropped (it would only add noise / leakage).
* Gender     -> protected characteristic, NOT used.
* Married    -> marital status is a protected characteristic in many lending laws, NOT used.
* Age, religion, caste, race are not used (age is not in the dataset anyway).
"""
import numpy as np
import pandas as pd

TARGET = "Loan_Status"  # "Y" = approved, "N" = rejected
ID_COLUMN = "Loan_ID"

NUMERIC_COLUMNS = ["ApplicantIncome", "CoapplicantIncome", "LoanAmount", "Loan_Amount_Term"]
BINARY_COLUMNS = ["Credit_History"]
CATEGORICAL_COLUMNS = ["Dependents", "Education", "Self_Employed", "Property_Area"]
FEATURE_COLUMNS = NUMERIC_COLUMNS + BINARY_COLUMNS + CATEGORICAL_COLUMNS
ENGINEERED_COLUMNS = ["Log_Total_Income", "Log_Loan_Amount", "Loan_To_Income"]
EXCLUDED_COLUMNS = ["Loan_ID", "Gender", "Married"]

# API value -> dataset value
EDUCATION_MAP = {"graduate": "Graduate", "not_graduate": "Not Graduate"}
EMPLOYMENT_MAP = {"self_employed": "Yes", "not_self_employed": "No"}
AREA_MAP = {"urban": "Urban", "semiurban": "Semiurban", "rural": "Rural"}


def add_engineered_features(df: pd.DataFrame) -> pd.DataFrame:
    """Derived columns. Lives inside the saved pipeline so inference matches training."""
    df = df.copy()
    applicant = pd.to_numeric(df["ApplicantIncome"], errors="coerce")
    coapplicant = pd.to_numeric(df["CoapplicantIncome"], errors="coerce")
    loan = pd.to_numeric(df["LoanAmount"], errors="coerce")
    total = applicant + coapplicant
    df["Log_Total_Income"] = np.log1p(total)
    df["Log_Loan_Amount"] = np.log1p(loan)
    # LoanAmount is in thousands, incomes are monthly -> ratio of loan to monthly income
    df["Loan_To_Income"] = (loan * 1000) / total.where(total > 0)
    return df


def api_to_model_row(clean: dict) -> pd.DataFrame:
    """Convert validated API input into a one-row DataFrame with dataset column names."""
    row = {
        "ApplicantIncome": float(clean["applicant_income"]),
        "CoapplicantIncome": float(clean["coapplicant_income"]),
        "LoanAmount": float(clean["loan_amount"]),
        "Loan_Amount_Term": float(clean["loan_term"]),
        "Credit_History": float(clean["credit_history"]),
        "Dependents": str(clean["dependents"]),
        "Education": EDUCATION_MAP[clean["education"]],
        "Self_Employed": EMPLOYMENT_MAP[clean["employment_status"]],
        "Property_Area": AREA_MAP[clean["property_area"]],
    }
    return pd.DataFrame([row], columns=FEATURE_COLUMNS)


FEATURE_LABELS = {
    "ApplicantIncome": "Applicant income",
    "CoapplicantIncome": "Co-applicant income",
    "LoanAmount": "Loan amount",
    "Loan_Amount_Term": "Loan term",
    "Credit_History": "Credit history",
    "Dependents": "Dependents",
    "Education": "Education",
    "Self_Employed": "Employment status",
    "Property_Area": "Property area",
}
