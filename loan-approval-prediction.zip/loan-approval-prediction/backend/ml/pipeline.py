"""Builds the scikit-learn pipeline: feature engineering -> imputation/scaling/encoding -> model."""
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

from ml.features import (
    BINARY_COLUMNS,
    CATEGORICAL_COLUMNS,
    ENGINEERED_COLUMNS,
    NUMERIC_COLUMNS,
    add_engineered_features,
)


def build_preprocessor():
    numeric = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())])
    binary = Pipeline([("imputer", SimpleImputer(strategy="most_frequent"))])
    categorical = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]
    )
    return ColumnTransformer(
        [
            ("num", numeric, NUMERIC_COLUMNS + ENGINEERED_COLUMNS),
            ("bin", binary, BINARY_COLUMNS),
            ("cat", categorical, CATEGORICAL_COLUMNS),
        ]
    )


def build_pipeline(estimator):
    return Pipeline(
        [
            ("engineer", FunctionTransformer(add_engineered_features, validate=False)),
            ("preprocess", build_preprocessor()),
            ("model", estimator),
        ]
    )
