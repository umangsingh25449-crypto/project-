"""Entry point.  Run the API with:  python run.py   (or: flask --app run run)"""
import os

from app import create_app

app = create_app()

if __name__ == "__main__":
    debug = os.environ.get("FLASK_ENV", "development") == "development"
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=debug)
