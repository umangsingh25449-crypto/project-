"""Synthetic data with the SAME columns as the Kaggle dataset. Used ONLY by automated tests."""
import numpy as np
import pandas as pd


def make_synthetic_dataset(n=400, seed=0):
    rng = np.random.default_rng(seed)
    income = rng.lognormal(8.5, 0.5, n).round()
    co_income = np.where(rng.random(n) < 0.4, 0, rng.lognormal(7.5, 0.6, n)).round()
    loan = np.clip(rng.normal(140, 60, n), 10, 600).round()
    credit = (rng.random(n) < 0.8).astype(float)
    logit = 3.0 * (credit - 0.5) + 0.0002 * (income + co_income) - 0.01 * loan + rng.normal(0, 0.7, n)
    df = pd.DataFrame(
        {
            "Loan_ID": [f"LP{i:06d}" for i in range(n)],
            "Gender": rng.choice(["Male", "Female"], n),
            "Married": rng.choice(["Yes", "No"], n),
            "Dependents": rng.choice(["0", "1", "2", "3+"], n),
            "Education": rng.choice(["Graduate", "Not Graduate"], n, p=[0.78, 0.22]),
            "Self_Employed": rng.choice(["Yes", "No"], n, p=[0.14, 0.86]),
            "ApplicantIncome": income,
            "CoapplicantIncome": co_income,
            "LoanAmount": loan,
            "Loan_Amount_Term": rng.choice([120, 180, 240, 360, 480], n, p=[0.02, 0.05, 0.03, 0.85, 0.05]),
            "Credit_History": credit,
            "Property_Area": rng.choice(["Urban", "Semiurban", "Rural"], n),
            "Loan_Status": np.where(logit > np.median(logit) - 0.8, "Y", "N"),
        }
    )
    # introduce missing values like the real dataset
    for col in ["Gender", "Dependents", "Self_Employed", "LoanAmount", "Loan_Amount_Term", "Credit_History"]:
        df.loc[rng.random(n) < 0.04, col] = np.nan
    return df
