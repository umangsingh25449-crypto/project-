import pytest

from app.models import LoanApplication
from tests.conftest import VALID_PREDICTION, auth_header


def test_prediction_requires_auth(client):
    assert client.post("/api/predictions", json=VALID_PREDICTION).status_code == 401


@pytest.mark.parametrize(
    "change",
    [
        {"applicant_income": -1},
        {"applicant_income": 0},
        {"coapplicant_income": -5},
        {"loan_amount": 0},
        {"loan_amount": "abc"},
        {"loan_term": 3},
        {"credit_history": 2},
        {"education": "phd"},
        {"property_area": None},
        {"dependents": "9"},
    ],
)
def test_prediction_validation(client, user_headers, change):
    res = client.post("/api/predictions", headers=user_headers, json={**VALID_PREDICTION, **change})
    assert res.status_code == 422
    assert res.get_json()["error"]["details"]


def test_prediction_missing_fields(client, user_headers):
    res = client.post("/api/predictions", headers=user_headers, json={})
    assert res.status_code == 422 and len(res.get_json()["error"]["details"]) == 9


def test_successful_inference_is_saved(client, user_headers):
    res = client.post("/api/predictions", headers=user_headers, json=VALID_PREDICTION)
    assert res.status_code == 201
    app_data = res.get_json()["data"]["application"]
    assert app_data["prediction_result"] in ("approved", "rejected")
    assert 0 <= app_data["prediction_score"] <= 1 and app_data["model_version"]
    assert LoanApplication.query.count() == 1
    assert client.get("/api/predictions", headers=user_headers).get_json()["data"]["pagination"]["total"] == 1


def test_client_cannot_force_result(client, user_headers):
    # A strong applicant who tries to force "rejected" still gets the model's decision, and vice versa.
    weak = {**VALID_PREDICTION, "credit_history": 0, "applicant_income": 1200, "coapplicant_income": 0, "loan_amount": 500}
    res = client.post("/api/predictions", headers=user_headers, json={**weak, "prediction_result": "approved", "user_id": 99})
    assert res.status_code == 201
    record = LoanApplication.query.first()
    assert record.user_id != 99 and record.prediction_result == res.get_json()["data"]["application"]["prediction_result"]


def test_history_filters_sort_pagination(client, user_headers):
    for amount in (100, 200, 300):
        client.post("/api/predictions", headers=user_headers, json={**VALID_PREDICTION, "loan_amount": amount})
    res = client.get("/api/predictions?per_page=2&sort_by=loan_amount&order=asc", headers=user_headers).get_json()["data"]
    assert [i["loan_amount"] for i in res["items"]] == [100, 200] and res["pagination"]["pages"] == 2


def test_user_data_isolation(client, user_headers):
    created = client.post("/api/predictions", headers=user_headers, json=VALID_PREDICTION).get_json()["data"]["application"]["id"]
    other = auth_header(client, "bob@example.com", "Bob Other")
    assert client.get("/api/predictions", headers=other).get_json()["data"]["items"] == []
    assert client.get(f"/api/predictions/{created}", headers=other).status_code == 404
    assert client.delete(f"/api/predictions/{created}", headers=other).status_code == 404
    assert client.get(f"/api/predictions/{created}", headers=user_headers).status_code == 200
    assert client.delete(f"/api/predictions/{created}", headers=user_headers).status_code == 200


def test_missing_model_gives_clear_error(client, app, user_headers, tmp_path):
    app.config["MODEL_PATH"] = str(tmp_path / "does_not_exist.joblib")
    res = client.post("/api/predictions", headers=user_headers, json=VALID_PREDICTION)
    assert res.status_code == 503
    assert res.get_json()["error"]["code"] == "MODEL_NOT_AVAILABLE"
    assert LoanApplication.query.count() == 0
    assert client.get("/api/predictions/model-info", headers=user_headers).status_code == 503
