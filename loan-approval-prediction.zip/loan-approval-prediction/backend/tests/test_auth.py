from app.models import User
from tests.conftest import login, register


def test_register_success_and_password_is_hashed(client):
    res = register(client)
    assert res.status_code == 201
    user = User.query.filter_by(email="alice@example.com").first()
    assert user.password_hash != "Passw0rdA" and "Passw0rdA" not in user.password_hash
    assert "password" not in str(res.get_json())


def test_register_duplicate_email(client):
    register(client)
    assert register(client).status_code == 409
    assert register(client, email="ALICE@example.com").status_code == 409


def test_register_validation(client):
    res = client.post("/api/auth/register", json={"full_name": "A", "email": "bad", "password": "short", "confirm_password": "x"})
    assert res.status_code == 422
    assert {"full_name", "email", "password"} <= set(res.get_json()["error"]["details"])


def test_login_success(client):
    register(client)
    res = login(client)
    assert res.status_code == 200 and res.get_json()["data"]["access_token"]


def test_invalid_login_is_generic(client):
    register(client)
    wrong_pw = login(client, password="WrongPass1")
    unknown = login(client, email="nobody@example.com")
    assert wrong_pw.status_code == unknown.status_code == 401
    assert wrong_pw.get_json()["error"]["message"] == unknown.get_json()["error"]["message"]


def test_protected_route_requires_token(client):
    assert client.get("/api/auth/me").status_code == 401
    assert client.get("/api/auth/me", headers={"Authorization": "Bearer garbage"}).status_code == 401


def test_me_and_change_password(client, user_headers):
    assert client.get("/api/auth/me", headers=user_headers).get_json()["data"]["user"]["email"] == "alice@example.com"
    bad = client.post("/api/auth/change-password", headers=user_headers,
                      json={"current_password": "nope", "new_password": "NewPassw0rd", "confirm_password": "NewPassw0rd"})
    assert bad.status_code == 422
    good = client.post("/api/auth/change-password", headers=user_headers,
                       json={"current_password": "Passw0rdA", "new_password": "NewPassw0rd", "confirm_password": "NewPassw0rd"})
    assert good.status_code == 200
    assert login(client, password="Passw0rdA").status_code == 401
    assert login(client, password="NewPassw0rd").status_code == 200


def test_profile_update_cannot_change_role(client, user_headers):
    res = client.put("/api/profile", headers=user_headers, json={"full_name": "New Name", "role": "admin"})
    assert res.status_code == 200
    user = res.get_json()["data"]["user"]
    assert user["full_name"] == "New Name" and user["role"] == "user"
