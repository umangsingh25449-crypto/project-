from tests.conftest import VALID_PREDICTION, auth_header


def test_dashboard_stats_come_from_database(client, user_headers):
    empty = client.get("/api/dashboard/stats", headers=user_headers).get_json()["data"]
    assert empty["total_predictions"] == 0
    for _ in range(3):
        client.post("/api/predictions", headers=user_headers, json=VALID_PREDICTION)
    stats = client.get("/api/dashboard/stats", headers=user_headers).get_json()["data"]
    assert stats["total_predictions"] == 3 and stats["approved"] + stats["rejected"] == 3
    activity = client.get("/api/dashboard/activity", headers=user_headers).get_json()["data"]
    assert len(activity["monthly"]) == 6 and activity["monthly"][-1]["total"] == 3 and len(activity["recent"]) == 3


def test_dashboard_stats_are_per_user(client, user_headers):
    client.post("/api/predictions", headers=user_headers, json=VALID_PREDICTION)
    other = auth_header(client, "bob@example.com", "Bob Other")
    assert client.get("/api/dashboard/stats", headers=other).get_json()["data"]["total_predictions"] == 0


def test_admin_endpoints_forbidden_for_normal_user(client, user_headers):
    for path in ("/api/admin/stats", "/api/admin/users", "/api/admin/applications"):
        assert client.get(path, headers=user_headers).status_code == 403
        assert client.get(path).status_code == 401


def test_admin_stats_users_and_applications(client, user_headers, admin_headers):
    client.post("/api/predictions", headers=user_headers, json=VALID_PREDICTION)
    stats = client.get("/api/admin/stats", headers=admin_headers).get_json()["data"]
    assert stats["total_users"] == 2 and stats["total_predictions"] == 1 and stats["recent_activity"]
    users = client.get("/api/admin/users", headers=admin_headers).get_json()["data"]["items"]
    assert "password_hash" not in str(users)
    apps = client.get("/api/admin/applications", headers=admin_headers).get_json()["data"]["items"]
    assert len(apps) == 1 and apps[0]["user"]["email"] == "alice@example.com"


def test_admin_can_manage_records_and_users(client, user_headers, admin_headers):
    app_id = client.post("/api/predictions", headers=user_headers, json=VALID_PREDICTION).get_json()["data"]["application"]["id"]
    assert client.delete(f"/api/admin/applications/{app_id}", headers=admin_headers).status_code == 200
    users = client.get("/api/admin/users", headers=admin_headers).get_json()["data"]["items"]
    alice = next(u for u in users if u["email"] == "alice@example.com")
    res = client.patch(f"/api/admin/users/{alice['id']}", headers=admin_headers, json={"is_active": False})
    assert res.status_code == 200
    assert client.get("/api/auth/me", headers=user_headers).status_code == 401  # deactivated users lose access
    admin = next(u for u in users if u["email"] == "admin@example.com")
    assert client.patch(f"/api/admin/users/{admin['id']}", headers=admin_headers, json={"role": "user"}).status_code == 403
