import pytest

from app import create_app
from app.config import TestConfig
from app.extensions import db
from app.models import User
from ml.train_model import train
from tests.synthetic_data import make_synthetic_dataset

VALID_PREDICTION = {
    "applicant_income": 5000,
    "coapplicant_income": 1500,
    "loan_amount": 120,
    "loan_term": 360,
    "credit_history": 1,
    "employment_status": "not_self_employed",
    "dependents": "0",
    "education": "graduate",
    "property_area": "urban",
}


@pytest.fixture(scope="session")
def model_dir(tmp_path_factory):
    """Trains a tiny real pipeline on SYNTHETIC data (tests only; the app never uses synthetic data)."""
    path = tmp_path_factory.mktemp("model")
    train(make_synthetic_dataset(), path, verbose=False)
    return path


@pytest.fixture()
def app(model_dir):
    class Cfg(TestConfig):
        MODEL_PATH = str(model_dir / "model.joblib")

    app = create_app(Cfg)
    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture()
def client(app):
    return app.test_client()


def register(client, email="alice@example.com", name="Alice Example", password="Passw0rdA"):
    return client.post(
        "/api/auth/register",
        json={"full_name": name, "email": email, "password": password, "confirm_password": password},
    )


def login(client, email="alice@example.com", password="Passw0rdA"):
    return client.post("/api/auth/login", json={"email": email, "password": password})


def auth_header(client, email="alice@example.com", name="Alice Example"):
    register(client, email, name)
    token = login(client, email).get_json()["data"]["access_token"]
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture()
def user_headers(client):
    return auth_header(client)


@pytest.fixture()
def admin_headers(client, app):
    register(client, "admin@example.com", "Admin User")
    user = User.query.filter_by(email="admin@example.com").first()
    user.role = "admin"
    db.session.commit()
    token = login(client, "admin@example.com").get_json()["data"]["access_token"]
    return {"Authorization": f"Bearer {token}"}
