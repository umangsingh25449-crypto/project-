import json

import pytest

from ml.features import EXCLUDED_COLUMNS, FEATURE_COLUMNS
from ml.predict import LoanModel, ModelNotAvailableError
from tests.conftest import VALID_PREDICTION


def test_model_predicts_with_valid_score(model_dir):
    out = LoanModel(model_dir / "model.joblib").predict(VALID_PREDICTION)
    assert out["result"] in ("approved", "rejected") and 0 <= out["score"] <= 1


def test_credit_history_matters(model_dir):
    model = LoanModel(model_dir / "model.joblib")
    good = model.predict(VALID_PREDICTION)["score"]
    bad = model.predict({**VALID_PREDICTION, "credit_history": 0})["score"]
    assert good > bad


def test_protected_attributes_not_used(model_dir):
    meta = json.loads((model_dir / "model_metadata.json").read_text())
    assert not {"Gender", "Married", "Loan_ID"} & set(meta["features_used"])
    assert set(meta["features_used"]) == set(FEATURE_COLUMNS) and "Gender" in EXCLUDED_COLUMNS
    assert meta["comparison"].keys() >= {"logistic_regression", "random_forest"}


def test_missing_artifact_raises(tmp_path):
    with pytest.raises(ModelNotAvailableError):
        LoanModel(tmp_path / "nope.joblib").predict(VALID_PREDICTION)
