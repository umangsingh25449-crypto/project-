import axios from "axios";

const TOKEN_KEY = "loan_app_token";
export const tokenStore = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
};

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000/api",
  timeout: 20000,
});

api.interceptors.request.use((config) => {
  const token = tokenStore.get();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (error) => {
    const isAuthCall = error.config?.url?.startsWith("/auth/login");
    if (error.response?.status === 401 && !isAuthCall && tokenStore.get()) {
      tokenStore.clear();
      window.dispatchEvent(new Event("auth:expired"));
    }
    return Promise.reject(error);
  }
);

/** Turn any axios error into { message, details, code, status }. */
export function parseError(error) {
  const body = error.response?.data?.error;
  if (body) return { message: body.message, details: body.details || {}, code: body.code, status: error.response.status };
  if (error.code === "ECONNABORTED") return { message: "The request timed out. Please try again.", details: {}, status: 0 };
  return { message: "Cannot reach the server. Is the backend running?", details: {}, code: "NETWORK", status: 0 };
}

const data = (res) => res.data.data;

export const authApi = {
  register: (body) => api.post("/auth/register", body).then(data),
  login: (body) => api.post("/auth/login", body).then(data),
  me: () => api.get("/auth/me").then(data),
  changePassword: (body) => api.post("/auth/change-password", body).then(data),
};
export const profileApi = {
  get: () => api.get("/profile").then(data),
  update: (body) => api.put("/profile", body).then(data),
};
export const predictionApi = {
  create: (body) => api.post("/predictions", body).then(data),
  list: (params) => api.get("/predictions", { params }).then(data),
  get: (id) => api.get(`/predictions/${id}`).then(data),
  remove: (id) => api.delete(`/predictions/${id}`).then(data),
  modelInfo: () => api.get("/predictions/model-info").then(data),
};
export const dashboardApi = {
  stats: () => api.get("/dashboard/stats").then(data),
  activity: () => api.get("/dashboard/activity").then(data),
};
export const adminApi = {
  stats: () => api.get("/admin/stats").then(data),
  users: (params) => api.get("/admin/users", { params }).then(data),
  updateUser: (id, body) => api.patch(`/admin/users/${id}`, body).then(data),
  applications: (params) => api.get("/admin/applications", { params }).then(data),
  deleteApplication: (id) => api.delete(`/admin/applications/${id}`).then(data),
};
export default api;
