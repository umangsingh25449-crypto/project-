import { Link } from "react-router-dom";

export default function Logo({ to = "/", light = false }) {
  return (
    <Link to={to} className="flex items-center gap-2.5" aria-label="Loan Approval Prediction System home">
      <svg viewBox="0 0 32 32" className="h-8 w-8" aria-hidden="true">
        <rect width="32" height="32" rx="8" fill={light ? "#14a39a" : "#0b2545"} />
        <path d="M8 20l5-5 4 4 7-8" fill="none" stroke={light ? "#0b2545" : "#3cbbb2"} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <span className={`font-display text-lg leading-none ${light ? "text-white" : "text-navy-900"}`}>
        LoanLens
        <span className={`block font-sans text-[10px] font-medium ${light ? "text-navy-100" : "text-slate-500"}`}>Approval Prediction System</span>
      </span>
    </Link>
  );
}
