import { AlertTriangle, ChevronLeft, ChevronRight, Info, Loader2 } from "lucide-react";

export function Spinner({ label = "Loading..." }) {
  return (
    <div className="flex items-center justify-center gap-2 py-16 text-slate-500" role="status">
      <Loader2 className="h-5 w-5 animate-spin" /> <span className="text-sm">{label}</span>
    </div>
  );
}

export function PageHeader({ title, subtitle, action }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-semibold text-navy-900 sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-slate-600">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function StatCard({ icon: Icon, label, value, hint, tone = "navy" }) {
  const tones = { navy: "bg-navy-100 text-navy-800", teal: "bg-teal-50 text-teal-700", red: "bg-red-50 text-red-700" };
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-slate-600">{label}</p>
        <span className={`rounded-lg p-2 ${tones[tone]}`}><Icon className="h-4 w-4" /></span>
      </div>
      <p className="mt-3 font-display text-3xl font-semibold text-navy-900">{value}</p>
      {hint && <p className="mt-1 text-xs text-slate-500">{hint}</p>}
    </div>
  );
}

export function ResultBadge({ result }) {
  const approved = result === "approved";
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${approved ? "bg-teal-50 text-teal-700" : "bg-red-50 text-red-700"}`}>
      {approved ? "Likely approved" : "Likely rejected"}
    </span>
  );
}

export function EmptyState({ icon: Icon, title, text, action }) {
  return (
    <div className="flex flex-col items-center px-6 py-14 text-center">
      <span className="rounded-full bg-teal-50 p-3 text-teal-600"><Icon className="h-6 w-6" /></span>
      <h3 className="mt-4 text-base font-semibold">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-slate-600">{text}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Field({ label, error, hint, htmlFor, children }) {
  return (
    <div>
      <label htmlFor={htmlFor} className="mb-1.5 block text-sm font-semibold text-navy-800">{label}</label>
      {children}
      {hint && !error && <p className="mt-1 text-xs text-slate-500">{hint}</p>}
      {error && <p className="mt-1 text-xs font-medium text-red-600" role="alert">{error}</p>}
    </div>
  );
}

export function Disclaimer({ className = "" }) {
  return (
    <div className={`flex gap-3 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900 ${className}`}>
      <Info className="mt-0.5 h-4 w-4 shrink-0" />
      <p>
        <strong>Educational estimate only.</strong> This is a student/learning project. Results are not actual bank
        lending decisions and must not be used for real credit decisions.
      </p>
    </div>
  );
}

export function ErrorBanner({ title = "Something went wrong", message }) {
  return (
    <div className="flex gap-3 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800" role="alert">
      <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />
      <div><p className="font-semibold">{title}</p><p className="mt-0.5">{message}</p></div>
    </div>
  );
}

export function Pagination({ pagination, onPage }) {
  if (!pagination || pagination.pages <= 1) return null;
  const { page, pages, total } = pagination;
  return (
    <div className="flex items-center justify-between border-t border-line px-4 py-3 text-sm">
      <p className="text-slate-600">{total} records - page {page} of {pages}</p>
      <div className="flex gap-2">
        <button className="btn-outline px-3 py-1.5" disabled={page <= 1} onClick={() => onPage(page - 1)} aria-label="Previous page"><ChevronLeft className="h-4 w-4" /></button>
        <button className="btn-outline px-3 py-1.5" disabled={page >= pages} onClick={() => onPage(page + 1)} aria-label="Next page"><ChevronRight className="h-4 w-4" /></button>
      </div>
    </div>
  );
}
