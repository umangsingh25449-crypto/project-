import Logo from "./Logo";
import { Disclaimer } from "./ui";

export default function AuthShell({ title, subtitle, children, footer }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
      <div className="hidden flex-col justify-between bg-navy-900 p-10 text-white lg:flex">
        <Logo light />
        <div>
          <h2 className="max-w-md text-4xl font-semibold leading-tight">Understand how a loan application looks to a model.</h2>
          <p className="mt-4 max-w-md text-navy-100">
            Enter application details, get an estimate from a trained scikit-learn pipeline, and keep a private history of
            what you tried.
          </p>
        </div>
        <p className="text-xs text-navy-100">Educational prototype - not a bank lending decision.</p>
      </div>
      <div className="flex items-center justify-center px-4 py-10">
        <div className="w-full max-w-md">
          <div className="mb-8 lg:hidden"><Logo /></div>
          <h1 className="text-3xl font-semibold">{title}</h1>
          <p className="mt-1 text-sm text-slate-600">{subtitle}</p>
          <div className="mt-6">{children}</div>
          <div className="mt-6 text-sm text-slate-600">{footer}</div>
          <Disclaimer className="mt-8" />
        </div>
      </div>
    </div>
  );
}
