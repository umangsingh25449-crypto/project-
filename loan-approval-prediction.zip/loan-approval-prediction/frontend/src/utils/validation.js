// Mirrors the backend rules (the backend always re-validates).
const EMAIL_RE = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

export function passwordError(pw) {
  if (!pw || pw.length < 8) return "Password must be at least 8 characters long.";
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return "Password must contain at least one letter and one number.";
  return null;
}

export function validateRegister(v) {
  const e = {};
  if (v.full_name.trim().length < 2) e.full_name = "Enter your full name (at least 2 characters).";
  if (!EMAIL_RE.test(v.email.trim())) e.email = "Enter a valid email address.";
  const pe = passwordError(v.password);
  if (pe) e.password = pe;
  if (v.confirm_password !== v.password) e.confirm_password = "Passwords do not match.";
  return e;
}

export function validatePassword({ current_password, new_password, confirm_password }) {
  const e = {};
  if (!current_password) e.current_password = "Current password is required.";
  const pe = passwordError(new_password);
  if (pe) e.new_password = pe;
  if (confirm_password !== new_password) e.confirm_password = "Passwords do not match.";
  return e;
}

const num = (v) => (v === "" || v === null || v === undefined ? NaN : Number(v));

export function validatePrediction(v) {
  const e = {};
  const income = num(v.applicant_income);
  if (Number.isNaN(income)) e.applicant_income = "Applicant income is required.";
  else if (income <= 0) e.applicant_income = "Applicant income must be greater than 0.";
  else if (income > 10_000_000) e.applicant_income = "Applicant income is too large.";

  const co = num(v.coapplicant_income);
  if (Number.isNaN(co)) e.coapplicant_income = "Enter 0 if there is no co-applicant income.";
  else if (co < 0) e.coapplicant_income = "Co-applicant income cannot be negative.";
  else if (co > 10_000_000) e.coapplicant_income = "Co-applicant income is too large.";

  const loan = num(v.loan_amount);
  if (Number.isNaN(loan)) e.loan_amount = "Loan amount is required.";
  else if (loan <= 0) e.loan_amount = "Loan amount must be greater than 0.";
  else if (loan > 10_000) e.loan_amount = "Loan amount cannot exceed 10,000 (thousands).";

  const term = num(v.loan_term);
  if (Number.isNaN(term)) e.loan_term = "Select a loan term.";
  else if (!Number.isInteger(term) || term < 12 || term > 480) e.loan_term = "Loan term must be between 12 and 480 months.";

  if (v.credit_history === "") e.credit_history = "Select a credit history option.";
  if (!v.employment_status) e.employment_status = "Select an employment status.";
  if (!v.dependents) e.dependents = "Select the number of dependents.";
  if (!v.education) e.education = "Select an education level.";
  if (!v.property_area) e.property_area = "Select a property area.";
  return e;
}
