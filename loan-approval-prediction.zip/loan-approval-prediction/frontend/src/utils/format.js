export const formatNumber = (n) => Number(n).toLocaleString("en-IN", { maximumFractionDigits: 2 });
export const formatLoan = (n) => `${formatNumber(n)}k`; // dataset stores loan amounts in thousands
export const formatDate = (iso) =>
  new Date(iso).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
export const formatDateTime = (iso) =>
  new Date(iso).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });

export const LABELS = {
  employment_status: { self_employed: "Self-employed", not_self_employed: "Not self-employed" },
  education: { graduate: "Graduate", not_graduate: "Not graduate" },
  property_area: { urban: "Urban", semiurban: "Semi-urban", rural: "Rural" },
  credit_history: { 1: "Meets guidelines", 0: "Does not meet guidelines" },
};
