import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { Disclaimer, ErrorBanner, Field, PageHeader } from "../components/ui";
import { useToast } from "../context/ToastContext";
import { parseError, predictionApi } from "../services/api";
import { validatePrediction } from "../utils/validation";

const EMPTY = {
  applicant_income: "", coapplicant_income: "0", loan_amount: "", loan_term: "360", credit_history: "",
  employment_status: "", dependents: "", education: "", property_area: "",
};
const TERMS = [12, 36, 60, 84, 120, 180, 240, 300, 360, 480];

function Radio({ name, value, current, onChange, label }) {
  const checked = String(current) === String(value);
  return (
    <label className={`flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-2.5 text-sm ${checked ? "border-teal-500 bg-teal-50 font-semibold" : "border-line bg-white"}`}>
      <input type="radio" name={name} value={value} checked={checked} onChange={onChange} className="accent-teal-600" /> {label}
    </label>
  );
}

export default function PredictionForm() {
  const navigate = useNavigate();
  const toast = useToast();
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [setupError, setSetupError] = useState("");
  const [serverError, setServerError] = useState("");

  useEffect(() => {
    predictionApi.modelInfo().catch((e) => {
      const err = parseError(e);
      if (err.code === "MODEL_NOT_AVAILABLE") setSetupError(err.message);
    });
  }, []);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const cls = (k) => `input ${errors[k] ? "input-error" : ""}`;

  const submit = async (e) => {
    e.preventDefault();
    setServerError("");
    const errs = validatePrediction(form);
    setErrors(errs);
    if (Object.keys(errs).length) {
      toast.error("Please correct the highlighted fields.");
      return;
    }
    setBusy(true);
    try {
      const res = await predictionApi.create({
        applicant_income: Number(form.applicant_income),
        coapplicant_income: Number(form.coapplicant_income),
        loan_amount: Number(form.loan_amount),
        loan_term: Number(form.loan_term),
        credit_history: Number(form.credit_history),
        employment_status: form.employment_status,
        dependents: form.dependents,
        education: form.education,
        property_area: form.property_area,
      });
      navigate(`/predictions/${res.application.id}`);
    } catch (err) {
      const { message, details, code } = parseError(err);
      if (code === "MODEL_NOT_AVAILABLE") setSetupError(message);
      else { setErrors(details || {}); setServerError(message); }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <PageHeader title="New prediction" subtitle="Enter the application details. All fields are required." />
      {setupError && (
        <div className="mb-5">
          <ErrorBanner title="Model setup required" message={`${setupError} See the README, section "Train the model".`} />
        </div>
      )}
      <form onSubmit={submit} noValidate className="card space-y-8 p-5 sm:p-7">
        {serverError && <ErrorBanner message={serverError} />}

        <section>
          <h2 className="mb-4 text-lg font-semibold">Income and loan</h2>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Applicant income (monthly)" htmlFor="applicant_income" error={errors.applicant_income} hint="Gross monthly income, same currency units as the dataset.">
              <input id="applicant_income" type="number" min="0" step="any" inputMode="decimal" className={cls("applicant_income")} value={form.applicant_income} onChange={set("applicant_income")} />
            </Field>
            <Field label="Co-applicant income (monthly)" htmlFor="coapplicant_income" error={errors.coapplicant_income} hint="Enter 0 if there is none.">
              <input id="coapplicant_income" type="number" min="0" step="any" inputMode="decimal" className={cls("coapplicant_income")} value={form.coapplicant_income} onChange={set("coapplicant_income")} />
            </Field>
            <Field label="Loan amount (in thousands)" htmlFor="loan_amount" error={errors.loan_amount} hint="Example: enter 120 for a loan of 120,000.">
              <input id="loan_amount" type="number" min="0" step="any" inputMode="decimal" className={cls("loan_amount")} value={form.loan_amount} onChange={set("loan_amount")} />
            </Field>
            <Field label="Loan term" htmlFor="loan_term" error={errors.loan_term}>
              <select id="loan_term" className={cls("loan_term")} value={form.loan_term} onChange={set("loan_term")}>
                {TERMS.map((t) => <option key={t} value={t}>{t} months ({(t / 12).toFixed(t % 12 ? 1 : 0)} years)</option>)}
              </select>
            </Field>
          </div>
        </section>

        <section>
          <h2 className="mb-4 text-lg font-semibold">Credit history</h2>
          <Field label="Does the applicant's credit history meet lender guidelines?" error={errors.credit_history}>
            <div className="grid gap-3 sm:grid-cols-2">
              <Radio name="credit_history" value="1" current={form.credit_history} onChange={set("credit_history")} label="Yes, meets guidelines" />
              <Radio name="credit_history" value="0" current={form.credit_history} onChange={set("credit_history")} label="No, does not meet guidelines" />
            </div>
          </Field>
        </section>

        <section>
          <h2 className="mb-4 text-lg font-semibold">Applicant profile</h2>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Employment status" error={errors.employment_status}>
              <div className="grid gap-3 sm:grid-cols-2">
                <Radio name="employment_status" value="not_self_employed" current={form.employment_status} onChange={set("employment_status")} label="Not self-employed" />
                <Radio name="employment_status" value="self_employed" current={form.employment_status} onChange={set("employment_status")} label="Self-employed" />
              </div>
            </Field>
            <Field label="Number of dependents" htmlFor="dependents" error={errors.dependents}>
              <select id="dependents" className={cls("dependents")} value={form.dependents} onChange={set("dependents")}>
                <option value="">Select...</option><option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3+">3 or more</option>
              </select>
            </Field>
            <Field label="Education level" htmlFor="education" error={errors.education}>
              <select id="education" className={cls("education")} value={form.education} onChange={set("education")}>
                <option value="">Select...</option><option value="graduate">Graduate</option><option value="not_graduate">Not graduate</option>
              </select>
            </Field>
            <Field label="Property area" htmlFor="property_area" error={errors.property_area}>
              <select id="property_area" className={cls("property_area")} value={form.property_area} onChange={set("property_area")}>
                <option value="">Select...</option><option value="urban">Urban</option><option value="semiurban">Semi-urban</option><option value="rural">Rural</option>
              </select>
            </Field>
          </div>
          <p className="mt-4 text-xs text-slate-500">
            Marital status, gender and age are intentionally not collected: they are protected characteristics (and age is
            not in the training dataset), so the model does not use them.
          </p>
        </section>

        <Disclaimer />
        <div className="flex justify-end">
          <button className="btn-teal px-6" disabled={busy || Boolean(setupError)}>
            {busy && <Loader2 className="h-4 w-4 animate-spin" />} {busy ? "Analysing..." : "Get prediction"}
          </button>
        </div>
      </form>
    </div>
  );
}
