import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { CheckCircle2, History, PlusCircle, Trash2, XCircle } from "lucide-react";
import { Disclaimer, ErrorBanner, PageHeader, Spinner } from "../components/ui";
import { useToast } from "../context/ToastContext";
import { parseError, predictionApi } from "../services/api";
import { formatDateTime, formatLoan, formatNumber, LABELS } from "../utils/format";

export default function PredictionResult() {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    setData(null);
    predictionApi.get(id).then(setData).catch((e) => setError(parseError(e).message));
  }, [id]);

  if (error) return <ErrorBanner title="Could not load this application" message={error} />;
  if (!data) return <Spinner />;

  const a = data.application;
  const approved = a.prediction_result === "approved";
  const score = a.prediction_score;

  const remove = async () => {
    if (!window.confirm("Delete this application record permanently?")) return;
    try {
      await predictionApi.remove(a.id);
      toast.success("Record deleted.");
      navigate("/history");
    } catch (e) {
      toast.error(parseError(e).message);
    }
  };

  const summary = [
    ["Applicant income", `${formatNumber(a.applicant_income)} / month`],
    ["Co-applicant income", `${formatNumber(a.coapplicant_income)} / month`],
    ["Loan amount", formatLoan(a.loan_amount)],
    ["Loan term", `${a.loan_term} months`],
    ["Credit history", LABELS.credit_history[a.credit_history]],
    ["Employment status", LABELS.employment_status[a.employment_status]],
    ["Dependents", a.dependents],
    ["Education", LABELS.education[a.education]],
    ["Property area", LABELS.property_area[a.property_area]],
  ];
  const maxImp = Math.max(...data.feature_importance.map((f) => f.importance), 0.0001);

  return (
    <div>
      <PageHeader title={`Application #${a.id}`} subtitle={`Submitted ${formatDateTime(a.created_at)} - model ${a.model_version}`} />

      <div className={`card flex flex-col gap-4 border-l-4 p-6 sm:flex-row sm:items-center ${approved ? "border-l-teal-500" : "border-l-red-500"}`}>
        {approved ? <CheckCircle2 className="h-12 w-12 shrink-0 text-teal-600" /> : <XCircle className="h-12 w-12 shrink-0 text-red-600" />}
        <div className="flex-1">
          <p className="text-sm text-slate-600">Model outcome</p>
          <h2 className="text-3xl font-semibold">{approved ? "Likely approved" : "Likely rejected"}</h2>
          <p className="mt-1 text-sm text-slate-600">
            {approved
              ? "Based on the information entered, the model classified this application as similar to approved applications in its training data."
              : "Based on the information entered, the model classified this application as similar to rejected applications in its training data. This is not a final decision and does not reflect your worth as a borrower."}
          </p>
        </div>
        {score !== null && (
          <div className="sm:w-44">
            <p className="text-xs text-slate-600">Model score (0 to 1)</p>
            <p className="font-display text-2xl font-semibold">{score.toFixed(2)}</p>
            <div className="mt-1 h-2 rounded-full bg-mist"><div className={`h-2 rounded-full ${approved ? "bg-teal-500" : "bg-red-500"}`} style={{ width: `${score * 100}%` }} /></div>
            <p className="mt-1 text-[11px] text-slate-500">A relative model score, not a calibrated or guaranteed probability.</p>
          </div>
        )}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="card p-5">
          <h2 className="text-lg font-semibold">Applicant summary</h2>
          <dl className="mt-3 divide-y divide-line">
            {summary.map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 py-2.5 text-sm"><dt className="text-slate-600">{k}</dt><dd className="text-right font-semibold">{v}</dd></div>
            ))}
          </dl>
        </div>

        <div className="space-y-6">
          {data.feature_importance.length > 0 && (
            <div className="card p-5">
              <h2 className="text-lg font-semibold">Inputs the model relies on most</h2>
              <p className="mt-1 text-xs text-slate-500">Overall importance measured on held-out test data during training. This describes the model in general, not a breakdown of this specific result.</p>
              <ul className="mt-4 space-y-3">
                {data.feature_importance.map((f) => (
                  <li key={f.feature}>
                    <div className="flex justify-between text-sm"><span>{f.label}</span><span className="text-slate-500">{Math.round(f.importance * 100)}%</span></div>
                    <div className="mt-1 h-2 rounded-full bg-mist"><div className="h-2 rounded-full bg-navy-700" style={{ width: `${(f.importance / maxImp) * 100}%` }} /></div>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {!approved && (
            <div className="card p-5">
              <h2 className="text-lg font-semibold">Areas you may want to review</h2>
              <ul className="mt-3 list-disc space-y-1.5 pl-5 text-sm text-slate-700">
                <li>Whether the credit history information entered is accurate.</li>
                <li>How the requested loan amount compares with household income.</li>
                <li>Whether a different loan term fits your situation.</li>
                <li>Whether other documented income should be included.</li>
              </ul>
              <p className="mt-3 text-xs text-slate-500">These are general areas, not instructions. Changing any field does not guarantee a different outcome.</p>
            </div>
          )}
        </div>
      </div>

      <div className="card mt-6 p-5">
        <h2 className="text-lg font-semibold">Limitations</h2>
        <ul className="mt-2 list-disc space-y-1.5 pl-5 text-sm text-slate-700">
          <li>The model was trained on a small public dataset and has not been validated for real lending.</li>
          <li>It has had no fairness testing or regulatory review, so it must not be used for real credit decisions.</li>
          <li>Real lenders consider many factors that are not captured here.</li>
        </ul>
      </div>

      <Disclaimer className="mt-6" />
      <div className="mt-6 flex flex-wrap gap-3">
        <Link to="/predict" className="btn-teal"><PlusCircle className="h-4 w-4" /> Make another prediction</Link>
        <Link to="/history" className="btn-outline"><History className="h-4 w-4" /> View application history</Link>
        <button onClick={remove} className="btn-danger sm:ml-auto"><Trash2 className="h-4 w-4" /> Delete record</button>
      </div>
    </div>
  );
}
