import { Link } from "react-router-dom";
import { BarChart3, Database, FileCheck2, History, Lock, ShieldCheck } from "lucide-react";
import Logo from "../components/Logo";
import { Disclaimer } from "../components/ui";
import { useAuth } from "../context/AuthContext";

const features = [
  { icon: FileCheck2, title: "Real model inference", text: "A scikit-learn pipeline trained on a public loan dataset scores every application. Nothing is hardcoded." },
  { icon: History, title: "Private history", text: "Every prediction is saved to your account with the model version, so you can search, filter and revisit it." },
  { icon: BarChart3, title: "Live dashboard", text: "Approval and rejection counts and monthly activity are calculated from your stored records." },
  { icon: ShieldCheck, title: "Fairness-aware features", text: "Gender and marital status are left out of the model on purpose, and the limits are stated on every result." },
  { icon: Lock, title: "Secure by default", text: "Hashed passwords, JWT sessions, ownership checks on every record and role-based admin access." },
  { icon: Database, title: "Portable data layer", text: "SQLAlchemy on SQLite for local work, ready to move to PostgreSQL." },
];

const steps = [
  ["Create an account", "Register and log in. Sessions use signed JWTs."],
  ["Enter application details", "Income, loan amount, term, credit history and the other fields the dataset supports."],
  ["Get an estimate", "The backend validates the input and runs the same preprocessing used in training."],
  ["Review and compare", "Open the result, then use your history to compare different scenarios."],
];

const stack = ["React + Vite", "Tailwind CSS", "Recharts", "Flask", "SQLAlchemy", "JWT", "scikit-learn", "SQLite"];

export default function Landing() {
  const { user } = useAuth();
  return (
    <div>
      <header className="border-b border-line bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
          <Logo />
          <div className="flex items-center gap-2">
            {user ? (
              <Link to="/dashboard" className="btn-primary">Open dashboard</Link>
            ) : (
              <>
                <Link to="/login" className="btn-outline">Login</Link>
                <Link to="/register" className="btn-primary hidden sm:inline-flex">Get started</Link>
              </>
            )}
          </div>
        </div>
      </header>

      <section className="bg-navy-900 text-white">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.15fr_1fr] lg:py-20">
          <div>
            <h1 className="text-4xl font-semibold leading-tight sm:text-5xl">See how a loan application reads to a trained model.</h1>
            <p className="mt-5 max-w-xl text-lg text-navy-100">
              Enter income, loan amount, term and credit history. Get a model-based estimate of approval likelihood, with
              the limits of that estimate spelled out.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/register" className="btn-teal px-6 py-3">Get started</Link>
              <Link to="/login" className="btn border border-white/30 px-6 py-3 text-white hover:bg-white/10">Login</Link>
            </div>
          </div>

          <div className="rounded-xl bg-white p-5 text-navy-900 shadow-card" aria-label="Example result card">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold">Example result</p>
              <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-900">Demo data</span>
            </div>
            <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
              {[["Applicant income", "5,000 / month"], ["Loan amount", "120k"], ["Term", "360 months"], ["Credit history", "Meets guidelines"]].map(([k, v]) => (
                <div key={k}><dt className="text-xs text-slate-500">{k}</dt><dd className="font-semibold">{v}</dd></div>
              ))}
            </dl>
            <div className="mt-5 rounded-lg bg-teal-50 p-4">
              <p className="text-xs text-teal-700">Model outcome</p>
              <p className="font-display text-2xl font-semibold text-teal-700">Likely approved</p>
              <div className="mt-3 h-2 rounded-full bg-white"><div className="h-2 w-[78%] rounded-full bg-teal-500" /></div>
              <p className="mt-2 text-xs text-slate-600">Illustrative score 0.78. Scores are not guaranteed probabilities.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <h2 className="text-3xl font-semibold">What you get</h2>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map(({ icon: Icon, title, text }) => (
            <div key={title} className="card p-5">
              <span className="inline-flex rounded-lg bg-teal-50 p-2 text-teal-700"><Icon className="h-5 w-5" /></span>
              <h3 className="mt-3 font-semibold">{title}</h3>
              <p className="mt-1 text-sm text-slate-600">{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-y border-line bg-white">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <h2 className="text-3xl font-semibold">How it works</h2>
          <ol className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {steps.map(([title, text], i) => (
              <li key={title}>
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-navy-900 font-display text-sm text-white">{i + 1}</span>
                <h3 className="mt-3 font-semibold">{title}</h3>
                <p className="mt-1 text-sm text-slate-600">{text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <h2 className="text-3xl font-semibold">Technology stack</h2>
        <div className="mt-6 flex flex-wrap gap-2">
          {stack.map((s) => <span key={s} className="rounded-full border border-line bg-white px-4 py-1.5 text-sm font-medium">{s}</span>)}
        </div>
        <Disclaimer className="mt-10" />
      </section>

      <footer className="bg-navy-900 text-navy-100">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-8 text-sm sm:px-6">
          <Logo light />
          <p>Educational machine learning project. Not financial advice and not a lending decision.</p>
        </div>
      </footer>
    </div>
  );
}
