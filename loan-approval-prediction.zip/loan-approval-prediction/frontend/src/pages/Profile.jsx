import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Loader2, LogOut } from "lucide-react";
import { Field, PageHeader } from "../components/ui";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { authApi, parseError, profileApi } from "../services/api";
import { formatDate } from "../utils/format";
import { validatePassword } from "../utils/validation";

export default function Profile() {
  const { user, setUser, logout } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [name, setName] = useState(user.full_name);
  const [nameError, setNameError] = useState("");
  const [total, setTotal] = useState(null);
  const [pw, setPw] = useState({ current_password: "", new_password: "", confirm_password: "" });
  const [pwErrors, setPwErrors] = useState({});
  const [busy, setBusy] = useState("");

  useEffect(() => { profileApi.get().then((d) => setTotal(d.total_predictions)).catch(() => {}); }, []);

  const saveName = async (e) => {
    e.preventDefault();
    if (name.trim().length < 2) return setNameError("Name must be at least 2 characters.");
    setNameError(""); setBusy("name");
    try {
      const d = await profileApi.update({ full_name: name });
      setUser(d.user); toast.success("Profile updated.");
    } catch (err) { setNameError(parseError(err).details?.full_name || parseError(err).message); }
    finally { setBusy(""); }
  };

  const savePassword = async (e) => {
    e.preventDefault();
    const errs = validatePassword(pw);
    setPwErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy("pw");
    try {
      await authApi.changePassword(pw);
      toast.success("Password changed.");
      setPw({ current_password: "", new_password: "", confirm_password: "" });
    } catch (err) {
      const { message, details } = parseError(err);
      setPwErrors(Object.keys(details).length ? details : { current_password: message });
    } finally { setBusy(""); }
  };

  const pwField = (id, label, auto) => (
    <Field label={label} htmlFor={id} error={pwErrors[id]}>
      <input id={id} type="password" autoComplete={auto} className={`input ${pwErrors[id] ? "input-error" : ""}`} value={pw[id]} onChange={(e) => setPw({ ...pw, [id]: e.target.value })} />
    </Field>
  );

  return (
    <div className="max-w-2xl">
      <PageHeader title="Profile" subtitle="Manage your account details." />

      <div className="card p-5">
        <dl className="grid gap-4 text-sm sm:grid-cols-3">
          <div><dt className="text-slate-500">Email</dt><dd className="break-all font-semibold">{user.email}</dd></div>
          <div><dt className="text-slate-500">Member since</dt><dd className="font-semibold">{formatDate(user.created_at)}</dd></div>
          <div><dt className="text-slate-500">Predictions made</dt><dd className="font-semibold">{total ?? "-"}</dd></div>
        </dl>
      </div>

      <form onSubmit={saveName} className="card mt-6 space-y-4 p-5" noValidate>
        <h2 className="text-lg font-semibold">Name</h2>
        <Field label="Full name" htmlFor="full_name" error={nameError}>
          <input id="full_name" className={`input ${nameError ? "input-error" : ""}`} value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <button className="btn-primary" disabled={busy === "name"}>{busy === "name" && <Loader2 className="h-4 w-4 animate-spin" />} Save name</button>
      </form>

      <form onSubmit={savePassword} className="card mt-6 space-y-4 p-5" noValidate>
        <h2 className="text-lg font-semibold">Change password</h2>
        {pwField("current_password", "Current password", "current-password")}
        {pwField("new_password", "New password", "new-password")}
        {pwField("confirm_password", "Confirm new password", "new-password")}
        <button className="btn-primary" disabled={busy === "pw"}>{busy === "pw" && <Loader2 className="h-4 w-4 animate-spin" />} Update password</button>
      </form>

      <button onClick={() => { logout(); navigate("/"); }} className="btn-outline mt-6"><LogOut className="h-4 w-4" /> Log out</button>
    </div>
  );
}
