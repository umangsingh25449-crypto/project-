import { useCallback, useEffect, useState } from "react";
import { ClipboardList, Percent, ShieldCheck, Trash2, Users } from "lucide-react";
import { ErrorBanner, PageHeader, Pagination, ResultBadge, Spinner, StatCard } from "../components/ui";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import useDebounce from "../hooks/useDebounce";
import { adminApi, parseError } from "../services/api";
import { formatDate, formatDateTime, formatLoan } from "../utils/format";

function Overview() {
  const [s, setS] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => { adminApi.stats().then(setS).catch((e) => setError(parseError(e).message)); }, []);
  if (error) return <ErrorBanner message={error} />;
  if (!s) return <Spinner />;
  return (
    <>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={Users} label="Registered users" value={s.total_users} hint={`${s.active_users} active, ${s.admins} admin`} />
        <StatCard icon={ClipboardList} label="Prediction records" value={s.total_predictions} hint={`${s.predictions_last_7_days} in the last 7 days`} />
        <StatCard icon={ShieldCheck} tone="teal" label="Predicted approvals" value={s.approved} />
        <StatCard icon={Percent} tone="red" label="Predicted rejections" value={s.rejected} hint={`Approval rate ${s.approval_rate}%`} />
      </div>
      <div className="card mt-6 overflow-hidden">
        <h2 className="p-5 text-lg font-semibold">Recent activity</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-mist"><tr><th className="th">ID</th><th className="th">User</th><th className="th">When</th><th className="th">Loan</th><th className="th">Result</th></tr></thead>
            <tbody className="divide-y divide-line">
              {s.recent_activity.map((a) => (
                <tr key={a.id}><td className="td">#{a.id}</td><td className="td">{a.user.full_name}</td><td className="td">{formatDateTime(a.created_at)}</td><td className="td">{formatLoan(a.loan_amount)}</td><td className="td"><ResultBadge result={a.prediction_result} /></td></tr>
              ))}
              {s.recent_activity.length === 0 && <tr><td className="td text-slate-500" colSpan={5}>No activity yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

function UsersTab() {
  const { user: me } = useAuth();
  const toast = useToast();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const q = useDebounce(search);

  const load = useCallback(() => {
    adminApi.users({ search: q, page, per_page: 10 }).then((d) => { setData(d); setError(""); }).catch((e) => setError(parseError(e).message));
  }, [q, page]);
  useEffect(load, [load]);
  useEffect(() => setPage(1), [q]);

  const patch = async (u, body) => {
    try { await adminApi.updateUser(u.id, body); toast.success("User updated."); load(); }
    catch (e) { toast.error(parseError(e).message); }
  };

  return (
    <div className="card overflow-hidden">
      <div className="p-4"><input className="input sm:max-w-sm" placeholder="Search name or email" aria-label="Search users" value={search} onChange={(e) => setSearch(e.target.value)} /></div>
      {error && <div className="px-4 pb-4"><ErrorBanner message={error} /></div>}
      {!data ? <Spinner /> : (
        <>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-mist"><tr><th className="th">Name</th><th className="th">Email</th><th className="th">Role</th><th className="th">Status</th><th className="th">Predictions</th><th className="th">Joined</th><th className="th"></th></tr></thead>
              <tbody className="divide-y divide-line">
                {data.items.map((u) => (
                  <tr key={u.id}>
                    <td className="td font-semibold">{u.full_name}</td><td className="td">{u.email}</td>
                    <td className="td capitalize">{u.role}</td>
                    <td className="td">{u.is_active ? <span className="text-teal-700">Active</span> : <span className="text-red-700">Disabled</span>}</td>
                    <td className="td">{u.prediction_count}</td><td className="td">{formatDate(u.created_at)}</td>
                    <td className="td text-right">
                      {u.id !== me.id && (
                        <span className="space-x-3">
                          <button className="font-semibold text-teal-700 hover:underline" onClick={() => patch(u, { role: u.role === "admin" ? "user" : "admin" })}>{u.role === "admin" ? "Make user" : "Make admin"}</button>
                          <button className="font-semibold text-red-700 hover:underline" onClick={() => patch(u, { is_active: !u.is_active })}>{u.is_active ? "Disable" : "Enable"}</button>
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination pagination={data.pagination} onPage={setPage} />
        </>
      )}
    </div>
  );
}

function ApplicationsTab() {
  const toast = useToast();
  const [result, setResult] = useState("");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const q = useDebounce(search);

  const load = useCallback(() => {
    adminApi.applications({ search: q, result: result || undefined, page, per_page: 10 }).then((d) => { setData(d); setError(""); }).catch((e) => setError(parseError(e).message));
  }, [q, result, page]);
  useEffect(load, [load]);
  useEffect(() => setPage(1), [q, result]);

  const remove = async (id) => {
    if (!window.confirm(`Delete application #${id}?`)) return;
    try { await adminApi.deleteApplication(id); toast.success("Record deleted."); load(); }
    catch (e) { toast.error(parseError(e).message); }
  };

  return (
    <div className="card overflow-hidden">
      <div className="flex flex-col gap-3 p-4 sm:flex-row">
        <input className="input sm:max-w-sm" placeholder="Search by ID, area or model version" aria-label="Search applications" value={search} onChange={(e) => setSearch(e.target.value)} />
        <select className="input sm:w-48" aria-label="Filter by result" value={result} onChange={(e) => setResult(e.target.value)}>
          <option value="">All results</option><option value="approved">Approved</option><option value="rejected">Rejected</option>
        </select>
      </div>
      {error && <div className="px-4 pb-4"><ErrorBanner message={error} /></div>}
      {!data ? <Spinner /> : (
        <>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-mist"><tr><th className="th">ID</th><th className="th">User</th><th className="th">Submitted</th><th className="th">Loan</th><th className="th">Result</th><th className="th">Model</th><th className="th"></th></tr></thead>
              <tbody className="divide-y divide-line">
                {data.items.map((a) => (
                  <tr key={a.id}>
                    <td className="td">#{a.id}</td><td className="td">{a.user.email}</td><td className="td">{formatDate(a.created_at)}</td>
                    <td className="td">{formatLoan(a.loan_amount)}</td><td className="td"><ResultBadge result={a.prediction_result} /></td>
                    <td className="td text-xs text-slate-500">{a.model_version}</td>
                    <td className="td text-right"><button aria-label={`Delete application ${a.id}`} onClick={() => remove(a.id)} className="text-slate-400 hover:text-red-600"><Trash2 className="h-4 w-4" /></button></td>
                  </tr>
                ))}
                {data.items.length === 0 && <tr><td className="td text-slate-500" colSpan={7}>No records found.</td></tr>}
              </tbody>
            </table>
          </div>
          <Pagination pagination={data.pagination} onPage={setPage} />
        </>
      )}
    </div>
  );
}

export default function Admin() {
  const [tab, setTab] = useState("overview");
  const tabs = [["overview", "Overview"], ["users", "Users"], ["applications", "Applications"]];
  return (
    <div>
      <PageHeader title="Admin dashboard" subtitle="Platform-wide statistics and record management." />
      <div className="mb-6 flex gap-1 border-b border-line" role="tablist">
        {tabs.map(([id, label]) => (
          <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
            className={`-mb-px border-b-2 px-4 py-2.5 text-sm font-semibold ${tab === id ? "border-teal-600 text-navy-900" : "border-transparent text-slate-500 hover:text-navy-800"}`}>{label}</button>
        ))}
      </div>
      {tab === "overview" && <Overview />}
      {tab === "users" && <UsersTab />}
      {tab === "applications" && <ApplicationsTab />}
    </div>
  );
}
