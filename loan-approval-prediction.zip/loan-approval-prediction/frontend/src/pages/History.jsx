import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowDown, ArrowUp, FileSearch, Search, Trash2 } from "lucide-react";
import { EmptyState, ErrorBanner, PageHeader, Pagination, ResultBadge, Spinner } from "../components/ui";
import { useToast } from "../context/ToastContext";
import useDebounce from "../hooks/useDebounce";
import { parseError, predictionApi } from "../services/api";
import { formatDate, formatLoan } from "../utils/format";

export default function History() {
  const toast = useToast();
  const [filters, setFilters] = useState({ search: "", result: "", sort_by: "created_at", order: "desc", page: 1 });
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const search = useDebounce(filters.search);

  const load = useCallback(() => {
    setLoading(true);
    predictionApi
      .list({ search, result: filters.result || undefined, sort_by: filters.sort_by, order: filters.order, page: filters.page, per_page: 10 })
      .then((d) => { setData(d); setError(""); })
      .catch((e) => setError(parseError(e).message))
      .finally(() => setLoading(false));
  }, [search, filters.result, filters.sort_by, filters.order, filters.page]);

  useEffect(load, [load]);

  const update = (patch) => setFilters((f) => ({ ...f, page: 1, ...patch }));
  const toggleSort = (col) =>
    update({ sort_by: col, order: filters.sort_by === col && filters.order === "desc" ? "asc" : "desc" });

  const remove = async (id) => {
    if (!window.confirm(`Delete application #${id}?`)) return;
    try { await predictionApi.remove(id); toast.success("Record deleted."); load(); }
    catch (e) { toast.error(parseError(e).message); }
  };

  const SortHead = ({ col, children }) => (
    <th className="th">
      <button className="inline-flex items-center gap-1 hover:text-navy-900" onClick={() => toggleSort(col)}>
        {children}
        {filters.sort_by === col && (filters.order === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
      </button>
    </th>
  );

  const nothingYet = data && data.pagination.total === 0 && !filters.search && !filters.result;

  return (
    <div>
      <PageHeader title="Application history" subtitle="Only you can see these records." action={<Link to="/predict" className="btn-teal">New prediction</Link>} />
      {error && <ErrorBanner message={error} />}

      <div className="card overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-line p-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <input className="input pl-9" placeholder="Search by ID (e.g. 12), area or model version" aria-label="Search" value={filters.search} onChange={(e) => update({ search: e.target.value })} />
          </div>
          <select className="input sm:w-48" aria-label="Filter by result" value={filters.result} onChange={(e) => update({ result: e.target.value })}>
            <option value="">All results</option><option value="approved">Approved</option><option value="rejected">Rejected</option>
          </select>
        </div>

        {loading && !data ? <Spinner /> : nothingYet ? (
          <EmptyState icon={FileSearch} title="No applications yet" text="Your saved predictions will appear here." action={<Link to="/predict" className="btn-teal">Make a prediction</Link>} />
        ) : data && data.items.length === 0 ? (
          <EmptyState icon={FileSearch} title="No matching records" text="Try a different search or filter." />
        ) : data && (
          <>
            <div className={`overflow-x-auto ${loading ? "opacity-60" : ""}`}>
              <table className="w-full">
                <thead className="bg-mist">
                  <tr>
                    <SortHead col="id">Application ID</SortHead><SortHead col="created_at">Submitted</SortHead>
                    <SortHead col="loan_amount">Loan amount</SortHead><SortHead col="prediction_result">Result</SortHead>
                    <th className="th">Model version</th><th className="th"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {data.items.map((a) => (
                    <tr key={a.id} className="hover:bg-mist/60">
                      <td className="td font-semibold">#{a.id}</td><td className="td">{formatDate(a.created_at)}</td>
                      <td className="td">{formatLoan(a.loan_amount)}</td><td className="td"><ResultBadge result={a.prediction_result} /></td>
                      <td className="td text-xs text-slate-500">{a.model_version}</td>
                      <td className="td text-right">
                        <Link to={`/predictions/${a.id}`} className="font-semibold text-teal-700 hover:underline">View</Link>
                        <button onClick={() => remove(a.id)} aria-label={`Delete application ${a.id}`} className="ml-4 text-slate-400 hover:text-red-600"><Trash2 className="inline h-4 w-4" /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination pagination={data.pagination} onPage={(page) => setFilters((f) => ({ ...f, page }))} />
          </>
        )}
      </div>
    </div>
  );
}
