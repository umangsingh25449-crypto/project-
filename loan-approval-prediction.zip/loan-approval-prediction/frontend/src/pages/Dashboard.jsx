import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CheckCircle2, ClipboardList, FilePlus2, XCircle } from "lucide-react";
import { EmptyState, ErrorBanner, PageHeader, ResultBadge, Spinner, StatCard } from "../components/ui";
import { useAuth } from "../context/AuthContext";
import { dashboardApi, parseError } from "../services/api";
import { formatDate, formatLoan } from "../utils/format";

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [activity, setActivity] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([dashboardApi.stats(), dashboardApi.activity()])
      .then(([s, a]) => { setStats(s); setActivity(a); })
      .catch((e) => setError(parseError(e).message));
  }, []);

  if (error) return <ErrorBanner message={error} />;
  if (!stats || !activity) return <Spinner />;

  const newBtn = <Link to="/predict" className="btn-teal"><FilePlus2 className="h-4 w-4" /> New prediction</Link>;

  return (
    <div>
      <PageHeader title={`Hello, ${user.full_name.split(" ")[0]}`} subtitle="A summary of the predictions you have made." action={newBtn} />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard icon={ClipboardList} label="Total predictions" value={stats.total_predictions} />
        <StatCard icon={CheckCircle2} tone="teal" label="Predicted approvals" value={stats.approved} hint={stats.total_predictions ? `${stats.approval_rate}% of your predictions` : undefined} />
        <StatCard icon={XCircle} tone="red" label="Predicted rejections" value={stats.rejected} />
      </div>

      {stats.total_predictions === 0 ? (
        <div className="card mt-6">
          <EmptyState icon={ClipboardList} title="No predictions yet" text="Run your first prediction to see statistics and charts here." action={newBtn} />
        </div>
      ) : (
        <>
          <div className="mt-6 grid gap-4 lg:grid-cols-5">
            <div className="card p-5 lg:col-span-2">
              <h2 className="text-lg font-semibold">Outcomes</h2>
              <div className="h-64">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={stats.distribution} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={2}>
                      <Cell fill="#14a39a" /><Cell fill="#c2410c" />
                    </Pie>
                    <Tooltip /><Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="card p-5 lg:col-span-3">
              <h2 className="text-lg font-semibold">Monthly activity</h2>
              <div className="h-64">
                <ResponsiveContainer>
                  <BarChart data={activity.monthly}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#dce3ec" vertical={false} />
                    <XAxis dataKey="label" tick={{ fontSize: 12 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                    <Tooltip /><Legend />
                    <Bar dataKey="approved" name="Approved" stackId="a" fill="#14a39a" />
                    <Bar dataKey="rejected" name="Rejected" stackId="a" fill="#c2410c" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="card mt-6 overflow-hidden">
            <div className="flex items-center justify-between p-5">
              <h2 className="text-lg font-semibold">Recent applications</h2>
              <Link to="/history" className="text-sm font-semibold text-teal-700 hover:underline">View all</Link>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-mist"><tr><th className="th">ID</th><th className="th">Date</th><th className="th">Loan amount</th><th className="th">Result</th><th className="th"></th></tr></thead>
                <tbody className="divide-y divide-line">
                  {activity.recent.map((a) => (
                    <tr key={a.id}>
                      <td className="td">#{a.id}</td><td className="td">{formatDate(a.created_at)}</td>
                      <td className="td">{formatLoan(a.loan_amount)}</td><td className="td"><ResultBadge result={a.prediction_result} /></td>
                      <td className="td text-right"><Link to={`/predictions/${a.id}`} className="font-semibold text-teal-700 hover:underline">View</Link></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
