import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Loader2 } from "lucide-react";
import AuthShell from "../components/AuthShell";
import { ErrorBanner, Field } from "../components/ui";
import { useToast } from "../context/ToastContext";
import { authApi, parseError } from "../services/api";
import { validateRegister } from "../utils/validation";

export default function Register() {
  const toast = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({ full_name: "", email: "", password: "", confirm_password: "" });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setServerError("");
    const errs = validateRegister(form);
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      await authApi.register(form);
      toast.success("Account created. Please log in.");
      navigate("/login");
    } catch (err) {
      const { message, details } = parseError(err);
      setErrors(details || {});
      setServerError(message);
    } finally {
      setBusy(false);
    }
  };

  const input = (id, label, type = "text", auto, hint) => (
    <Field label={label} htmlFor={id} error={errors[id]} hint={hint}>
      <input id={id} type={type} autoComplete={auto} className={`input ${errors[id] ? "input-error" : ""}`} value={form[id]} onChange={set(id)} />
    </Field>
  );

  return (
    <AuthShell
      title="Create your account"
      subtitle="It takes less than a minute."
      footer={<>Already registered? <Link to="/login" className="font-semibold text-teal-700 hover:underline">Log in</Link></>}
    >
      <form onSubmit={submit} className="space-y-4" noValidate>
        {serverError && <ErrorBanner title="Registration failed" message={serverError} />}
        {input("full_name", "Full name", "text", "name")}
        {input("email", "Email", "email", "email")}
        {input("password", "Password", "password", "new-password", "At least 8 characters, with a letter and a number.")}
        {input("confirm_password", "Confirm password", "password", "new-password")}
        <button className="btn-primary w-full" disabled={busy}>
          {busy && <Loader2 className="h-4 w-4 animate-spin" />} Create account
        </button>
      </form>
    </AuthShell>
  );
}
