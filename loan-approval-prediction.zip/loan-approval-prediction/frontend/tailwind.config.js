/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        navy: { 950: "#071a33", 900: "#0b2545", 800: "#13315c", 700: "#1d4575", 600: "#2d5a8e", 100: "#dbe5f1" },
        teal: { 50: "#e8f6f5", 100: "#c9ebe8", 400: "#3cbbb2", 500: "#14a39a", 600: "#0f8a82", 700: "#0c6e68" },
        mist: "#f4f7fa",
        line: "#dce3ec",
      },
      fontFamily: {
        sans: ["Manrope", "system-ui", "Segoe UI", "sans-serif"],
        display: ["Fraunces", "Georgia", "serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(11,37,69,.06), 0 4px 16px rgba(11,37,69,.06)",
      },
    },
  },
  plugins: [],
};
