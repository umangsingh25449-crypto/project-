# Loan Approval Prediction System

A full-stack **educational** web app: React (Vite + Tailwind) frontend, Flask REST API, SQLAlchemy database and a
scikit-learn model pipeline.

> **Predictions are educational estimates, not actual bank lending decisions.** The model has had no fairness
> testing or regulatory review and must not be used for real credit decisions.

## Status of this code (please read)
* The ML pipeline (`train_model.py`, `evaluate_model.py`, `predict.py`) was **executed end-to-end on synthetic data**
  and worked. It has **not** been run on the real Kaggle dataset, because that file must be downloaded by you.
* The Flask API, the test suite and the React frontend were **written but not executed** (the build environment had no
  internet access to install Flask extensions or npm packages). The JSX files passed a syntax check only.
  Expect to fix a small bug or two on first run; use section 13 and the test suite to find them.

## 1. Architecture
```
React (Vite, :5173)  --Axios/JWT-->  Flask API (:5000)  --SQLAlchemy-->  SQLite (backend/instance/loan_app.db)
                                          |
                                          +-- ml/predict.py loads ml/artifacts/model.joblib (Joblib pipeline)
```
```
loan-approval-prediction/
|-- dataset/            README.md (how to get the data), put loan_train.csv here
|-- backend/
|   |-- app/            __init__.py (factory), config.py, extensions.py, cli.py
|   |   |-- models/     User, LoanApplication
|   |   |-- routes/     auth, predictions, dashboard, profile, admin
|   |   |-- schemas/    validators.py (server-side validation)
|   |   |-- services/   prediction_service.py
|   |   `-- utils/      responses.py (JSON envelope), auth.py (JWT + roles)
|   |-- ml/             features.py, pipeline.py, train_model.py, evaluate_model.py, predict.py, artifacts/
|   |-- tests/          pytest suite (separate in-memory test DB)
|   |-- requirements.txt, run.py, .env.example
`-- frontend/           src/{components,pages,layouts,services,hooks,context,utils}, package.json, .env.example
```

## 2. Prerequisites (Windows)
* **Python 3.10+** from python.org (tick "Add python.exe to PATH")
* **Node.js 18+ (LTS)** from nodejs.org
* **VS Code** (+ the Python extension), and a free **Kaggle** account for the dataset

## 3. Backend setup (PowerShell, in VS Code: Terminal > New Terminal)
```powershell
cd loan-approval-prediction\backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
# If activation is blocked:  Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
pip install -r requirements.txt
Copy-Item .env.example .env
```
Open `backend\.env` and replace the two secrets. Generate them with:
```powershell
python -c "import secrets; print(secrets.token_urlsafe(48))"
```
Run it twice: one value for `SECRET_KEY`, a different one for `JWT_SECRET_KEY`.

## 4. Dataset
Follow `dataset/README.md` and save the file as `dataset\loan_train.csv`. The scripts stop with a clear error if it is missing.

## 5. Train and evaluate the model
```powershell
# still in backend\ with the venv active
python -m ml.train_model
python -m ml.evaluate_model
```
Training compares **Logistic Regression** and **Random Forest** (class-balanced, 5-fold CV grid search), selects by
cross-validated **ROC-AUC** (not accuracy), then reports accuracy, precision, recall, F1, ROC-AUC and the confusion matrix
on a stratified 20% held-out test set. Imputers, scaler and encoder live inside the saved pipeline, so inference uses
exactly the training preprocessing. Outputs: `ml\artifacts\model.joblib` and `model_metadata.json` (version, metrics,
features used/excluded, feature importance). Gender and marital status are excluded on purpose.

If the model file is missing the API returns `503 MODEL_NOT_AVAILABLE` and the form shows a setup banner.
Nothing is ever faked.

## 6. Database and first administrator
```powershell
flask --app run init-db
flask --app run create-admin --email you@example.com --name "Your Name"
```
The password is typed at a hidden prompt, so it is never in a file or your shell history. Running `create-admin` for an
existing email promotes that user. Admins can promote others in the Admin > Users tab. Tables are created with
SQLAlchemy `create_all`. For PostgreSQL, install `psycopg2-binary`, set `DATABASE_URL`, and (for schema changes over
time) add Flask-Migrate.

## 7. Start the backend
```powershell
python run.py
```
Check http://127.0.0.1:5000/api/health

## 8. Start the frontend (a second terminal)
```powershell
cd loan-approval-prediction\frontend
Copy-Item .env.example .env
npm install
npm run dev
```
Open **http://localhost:5173**. (`CORS_ORIGINS` in `backend\.env` must contain this origin.)

## 9. Test the API from PowerShell
```powershell
$base = "http://127.0.0.1:5000/api"
Invoke-RestMethod "$base/auth/register" -Method Post -ContentType "application/json" -Body '{"full_name":"Test User","email":"test@example.com","password":"Passw0rdA","confirm_password":"Passw0rdA"}'
$login = Invoke-RestMethod "$base/auth/login" -Method Post -ContentType "application/json" -Body '{"email":"test@example.com","password":"Passw0rdA"}'
$h = @{ Authorization = "Bearer $($login.data.access_token)" }
Invoke-RestMethod "$base/predictions" -Method Post -Headers $h -ContentType "application/json" -Body '{"applicant_income":5000,"coapplicant_income":1500,"loan_amount":120,"loan_term":360,"credit_history":1,"employment_status":"not_self_employed","dependents":"0","education":"graduate","property_area":"urban"}'
Invoke-RestMethod "$base/dashboard/stats" -Headers $h
```

## 10. Automated tests
```powershell
cd loan-approval-prediction\backend
pytest -v
```
Tests use an in-memory SQLite database and a tiny model trained on **synthetic** data (tests only), so they need
neither your real database nor the Kaggle file. They cover registration/login, duplicate email, invalid login,
protected routes, input validation, real inference, history saving, user isolation, admin authorization, dashboard
statistics and missing-model handling.

## 11. API reference
All responses: `{"success": true, "message": "...", "data": {...}}` or
`{"success": false, "error": {"code": "...", "message": "...", "details": {...}}}`.
Authenticated routes need `Authorization: Bearer <token>`.

| Method & path | Auth | Purpose |
|---|---|---|
| POST `/api/auth/register` | - | `full_name, email, password, confirm_password` -> 201 / 409 duplicate / 422 |
| POST `/api/auth/login` | - | `email, password` -> `access_token, user` (generic 401 on failure) |
| GET `/api/auth/me` | user | Current user |
| POST `/api/auth/change-password` | user | `current_password, new_password, confirm_password` |
| POST `/api/predictions` | user | Body: `applicant_income, coapplicant_income, loan_amount (thousands), loan_term (months 12-480), credit_history (0/1), employment_status (self_employed/not_self_employed), dependents (0/1/2/3+), education (graduate/not_graduate), property_area (urban/semiurban/rural)` -> 201, 422, or 503 if model missing |
| GET `/api/predictions` | user | Own records. Query: `page, per_page, search, result, sort_by (created_at/loan_amount/id/prediction_result), order, date_from, date_to` |
| GET `/api/predictions/<id>` | user | Own record (404 for others' records) |
| DELETE `/api/predictions/<id>` | user | Delete own record |
| GET `/api/predictions/model-info` | user | Model version, metrics, features used/excluded |
| GET `/api/dashboard/stats` | user | Totals, approvals, rejections, distribution |
| GET `/api/dashboard/activity` | user | Last 6 months + 5 recent applications |
| GET / PUT `/api/profile` | user | View / update `full_name` |
| GET `/api/admin/stats` | admin | Users, predictions, outcomes, recent activity |
| GET `/api/admin/users` | admin | Paginated, `search` |
| PATCH `/api/admin/users/<id>` | admin | `role` and/or `is_active` (not on yourself) |
| GET `/api/admin/applications` | admin | All records, same filters as history |
| DELETE `/api/admin/applications/<id>` | admin | Delete any record |

Rate limits: login 10/min, register 10/hour, change-password 10/hour, predictions 30/min (per IP, in-memory store).

## 12. Security notes
Passwords hashed by Werkzeug; secrets only from environment variables; backend re-validates everything; ORM queries
only; ownership enforced in every query; admin routes check the role on each request; deactivated users lose access
immediately; stack traces go to logs, never to clients; passwords and tokens are never logged.
The frontend stores the JWT in `localStorage` (simple for learning; an httpOnly cookie is stronger for production).

## 13. Common errors
| Problem | Fix |
|---|---|
| `Activate.ps1 cannot be loaded` | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| `SECRET_KEY and JWT_SECRET_KEY must be set` | Create `backend\.env` from `.env.example` and fill both |
| `No module named 'app'` / `'ml'` | Run commands from the `backend\` folder with the venv active |
| `Dataset not found` | Put `loan_train.csv` in `dataset\` (see dataset/README.md) |
| 503 `MODEL_NOT_AVAILABLE` / setup banner | Run `python -m ml.train_model` |
| Model fails to load after upgrading scikit-learn | Re-run `python -m ml.train_model` |
| Browser "CORS" error / "Cannot reach the server" | Backend not running, or `CORS_ORIGINS` / `VITE_API_URL` mismatch; restart after editing `.env` |
| `no such table: users` | Run `flask --app run init-db` |
| Port 5000 in use | Set `PORT=5001` and change `VITE_API_URL` |

## 14. Deploying safely
Use PostgreSQL; set strong unique secrets; `FLASK_ENV=production`; serve Flask with `waitress-serve --port=8000 run:app`
(or gunicorn on Linux) behind HTTPS; set `CORS_ORIGINS` to your real domain only; use Redis for `RATELIMIT_STORAGE_URI`;
`npm run build` and serve `frontend/dist`; back up the database; keep the educational disclaimer visible.

## 15. Final verification checklist
- [ ] `pytest -v` passes
- [ ] `python -m ml.train_model` finishes and creates `ml\artifacts\model.joblib`
- [ ] Register a new account (duplicate email is rejected)
- [ ] Log in, and `/dashboard` redirects to `/login` when logged out
- [ ] Dashboard shows empty state, then counts after predictions
- [ ] Submit a prediction -> result page shows outcome, score, summary, limitations
- [ ] Invalid input (negative income, loan amount 0) shows validation messages
- [ ] History lists the record; search, filter, sort and pagination work
- [ ] A second user cannot see the first user's records
- [ ] Profile: name update and password change work
- [ ] `create-admin` user sees the Admin menu; normal users do not (and get 403 from the API)
- [ ] Stopping the model (rename `model.joblib`) shows the setup error instead of a fake result
