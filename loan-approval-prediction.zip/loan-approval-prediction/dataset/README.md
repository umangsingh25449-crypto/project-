# Dataset setup

The model is trained on the public **Kaggle "Loan Prediction Problem Dataset"** (Analytics Vidhya).
The dataset is **not included** in this repository and is not downloaded automatically.

## Steps
1. Create a free Kaggle account and search for **"Loan Prediction Problem Dataset"**.
2. Download the **training file** (usually `train_u6lujuX_CVtuZ9i.csv`, ~614 rows).
3. Copy it into this folder and rename it to **`loan_train.csv`**
   (or keep the name and pass `--data` to the training script).

Final path: `loan-approval-prediction/dataset/loan_train.csv`

## Columns and how the project uses them
| Dataset column | Used? | API / form field | Notes |
|---|---|---|---|
| Loan_ID | No | - | Identifier, dropped |
| Gender | **No** | - | Protected characteristic |
| Married | **No** | - | Marital status excluded by the feature policy |
| Dependents | Yes | `dependents` | `0`, `1`, `2`, `3+` |
| Education | Yes | `education` | `graduate` -> Graduate, `not_graduate` -> Not Graduate |
| Self_Employed | Yes | `employment_status` | `self_employed` -> Yes, `not_self_employed` -> No |
| ApplicantIncome | Yes | `applicant_income` | Monthly income |
| CoapplicantIncome | Yes | `coapplicant_income` | Monthly income |
| LoanAmount | Yes | `loan_amount` | **In thousands** |
| Loan_Amount_Term | Yes | `loan_term` | Months |
| Credit_History | Yes | `credit_history` | 1 = meets guidelines, 0 = does not |
| Property_Area | Yes | `property_area` | `urban`, `semiurban`, `rural` |
| Loan_Status | Target | - | `Y` = approved (1), `N` = rejected (0) |

Age is **not** in this dataset, so the app does not ask for it.
Three engineered features (log total income, log loan amount, loan-to-income ratio) are computed inside the saved pipeline.
